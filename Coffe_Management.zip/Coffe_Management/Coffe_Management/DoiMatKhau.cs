﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Coffe_Management
{
    public partial class DoiMatKhau : Form
    {
        private string tk;
        Data data = new Data();
        public DoiMatKhau(string tk)
        {
            InitializeComponent();
            this.tk = tk;
        }
        private void btnDoi_Click(object sender, EventArgs e)
        {
            bool check = false;
            if (txtMKcu.Text.Length == 0 || txtMKmoi.Text.Length == 0 || txtRepeatMK.Text.Length == 0)
            {
                if (txtMKcu.Text.Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập mật khẩu cũ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtMKcu.Focus();
                }else
                if (txtMKmoi.Text.Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập mật khẩu mới", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtMKmoi.Focus();
                }else
                if (txtRepeatMK.Text.Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập xác nhận mật khẩu mới", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtRepeatMK.Focus();
                }
            }
            else
            {
                string query = "SELECT MATKHAU FROM TAIKHOAN WHERE TAIKHOAN = @Value1";
                SqlParameter p = new SqlParameter("@Value1", tk);
                string cellvalue = data.Scalar(query, p);
                if (cellvalue.Equals(txtMKcu.Text))
                {
                    if (txtMKmoi.Text.Equals(txtRepeatMK.Text))
                    {
                        check = true;
                    }
                    else
                    {
                        MessageBox.Show("Xác nhận mật khẩu không khớp", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtRepeatMK.Clear();
                        txtRepeatMK.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Mật khẩu cũ không khớp", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtMKcu.Clear();
                    txtMKcu.Focus();
                }
            }
            if (check)
            {
                string query = "UPDATE TAIKHOAN SET MATKHAU = @Value1 WHERE TAIKHOAN = @Value2";
                SqlParameter[] p =
                {
                    new SqlParameter("@Value1",txtMKmoi.Text),
                    new SqlParameter("Value2",tk)
                };
                if (data.Excute(query, p))
                {
                    MessageBox.Show("Đổi mật khẩu thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Có lỗi xảy ra", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void txtMKcu_TextChanged(object sender, EventArgs e)
        {
            errorProvider1.SetError(this.txtMKcu, null);
        }

        private void txtMKmoi_TextChanged(object sender, EventArgs e)
        {
            errorProvider1.SetError(this.txtMKmoi, null);
        }

        private void txtRepeatMK_TextChanged(object sender, EventArgs e)
        {
            errorProvider1.SetError(this.txtRepeatMK, null);
        }

        private void DoiMatKhau_Load(object sender, EventArgs e)
        {

        }

        private void btnThoat_DoiMatKhau_Click(object sender, EventArgs e)
        {
            DialogResult tl = MessageBox.Show("Bạn có muốn thoát không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (tl == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
