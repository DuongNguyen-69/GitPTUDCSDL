﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Coffe_Management
{
    public partial class fTaoTaiKhoan : Form
    {
        public fTaoTaiKhoan()
        {
            InitializeComponent();
        }
        Data data = new Data();
        private void btnTaoTK_fTaoTK_Click(object sender, EventArgs e)
        {
            if (txtTaiKhoan_fTaoTK.Text.Length == 0 || txtMatKhau_fTaoTK.Text.Length == 0 || txtNhapLaiMatKhau_fTaoTK.Text.Length == 0 || txtTenHienThi_fTaoTK.Text.Length == 0)
            {
                if (txtTaiKhoan_fTaoTK.Text.Length == 0)
                {
                    MessageBox.Show("Chưa nhập tài khoản", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtTaiKhoan_fTaoTK.Focus();
                }else
                if (txtTenHienThi_fTaoTK.Text.Length == 0)
                {
                    MessageBox.Show("Chưa nhập tên hiển thị", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtTenHienThi_fTaoTK.Focus();
                }else
                if (txtMatKhau_fTaoTK.Text.Length == 0)
                {
                    MessageBox.Show("Chưa nhập mật khẩu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtMatKhau_fTaoTK.Focus();
                }else
                if (txtNhapLaiMatKhau_fTaoTK.Text.Length == 0)
                {
                    MessageBox.Show("Chưa nhập xác nhận mật khẩu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtNhapLaiMatKhau_fTaoTK.Focus();
                }
            }
            else
            {
                if (!txtMatKhau_fTaoTK.Text.Equals(txtNhapLaiMatKhau_fTaoTK.Text))
                {
                    MessageBox.Show("Xác nhận mật khẩu không khớp", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtNhapLaiMatKhau_fTaoTK.Clear();
                    txtNhapLaiMatKhau_fTaoTK.Focus();
                }
                else
                {
                    string query = "SELECT TAIKHOAN FROM TAIKHOAN WHERE TAIKHOAN = @Value1";
                    SqlParameter p = new SqlParameter("@Value1", txtTaiKhoan_fTaoTK.Text);
                    string valueCell = data.Scalar(query, p);
                    if (!string.IsNullOrEmpty(valueCell))
                    {
                        MessageBox.Show("Tài khoản đã tồn tại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtTaiKhoan_fTaoTK.Clear();
                        txtTaiKhoan_fTaoTK.Focus();
                    }
                    else
                    {
                        string query2 = "INSERT INTO TAIKHOAN VALUES(@Value1, @Value2, @Value3, 1)";
                        SqlParameter[] args =
                        {
                            new SqlParameter("@Value1", txtTaiKhoan_fTaoTK.Text),
                            new SqlParameter("@Value2", txtTenHienThi_fTaoTK.Text),
                            new SqlParameter("@Value3", txtMatKhau_fTaoTK.Text)
                        };

                        if (data.Excute(query2, args))
                        {
                            MessageBox.Show("Tạo tài khoản thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.Close();
                        }
                    }
                }
            }
        }

        private void btnThoat_fTaoTK_Click(object sender, EventArgs e)
        {
            DialogResult tl = MessageBox.Show("Bạn có muốn thoát không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (tl == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
