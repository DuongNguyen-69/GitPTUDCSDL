﻿using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.Globalization;
using System.Windows.Forms;

namespace Coffe_Management
{
    public partial class Coffee : Form
    {
        private fLogin loginform;
        Data data = null;
        String taikhoan = "";

        public Coffee(fLogin loginform, String tk)
        {
            InitializeComponent();
            this.loginform = loginform;
            this.taikhoan = tk;
        }

        private void Coffee_FormClosing(object sender, FormClosingEventArgs e)
        {

            loginform.Show();
            loginform.FormClosed += (s, args) => this.Close();
            this.Hide();

            // this.Close();
            // loginform.Close();
        }

        private void btnDoiMK_Click(object sender, EventArgs e)
        {
            if (dgvTK.SelectedCells.Count > 0)
            {
                DataGridViewCell selectedCell = dgvTK.SelectedCells[0];
                int rowIndex = selectedCell.RowIndex;
                if (rowIndex < 0 || rowIndex >= dgvTK.RowCount)
                {
                    MessageBox.Show("Vui lòng chọn tài khoản muốn đổi mật khẩu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    string query = "SELECT TAIKHOAN FROM TAIKHOAN WHERE TAIKHOAN = @Value1";
                    SqlParameter p = new SqlParameter("@Value1", dgvTK.Rows[rowIndex].Cells[0].Value.ToString());
                    string cellValue = data.Scalar(query, p);
                    DoiMatKhau doiMatKhau = new DoiMatKhau(cellValue);
                    doiMatKhau.Show();
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn tài khoản muốn đổi mật khẩu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void dtvgMenu_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                cb_LoaiMon.Text = dtvgMenu.Rows[e.RowIndex].Cells["TenLoaiMonMenu"].Value.ToString();
                txt_MaMon.Text = dtvgMenu.Rows[e.RowIndex].Cells["MaMonMenu"].Value.ToString();
                txt_TenMon.Text = dtvgMenu.Rows[e.RowIndex].Cells["TenMonMenu"].Value.ToString();
                txt_DonGia.Text = dtvgMenu.Rows[e.RowIndex].Cells["GiaMenu"].Value.ToString();
            }
        }

        public void LoadMenu_dgvMon()
        {
            string query = "select MAMON, TENMON, TENLOAI, GIA from MON join LOAIMON on MON.MALOAI = LOAIMON.MALOAI ";
            Data dt = new Data();
            dtvgMenu.DataSource = dt.GetData(query);
        }

        private void btn_TimKiemMenu_Click(object sender, EventArgs e)
        {
            string query = "SELECT MAMON, TENMON,TENLOAI,GIA FROM MON JOIN LOAIMON ON MON.MALOAI = LOAIMON.MALOAI WHERE ";
            int check = 0;
            if (ckbTK_TenMon.Checked == true)
            {
                if (txt_TenMon.Text != "")
                {
                    query += "MON.TENMON LIKE @TENMON";
                    check++;
                }
                else
                {
                    MessageBox.Show("Bạn chưa nhập tên món cần tìm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txt_TenMon.Focus();
                    return;
                }
            }
            if (ckbTK_LoaiMon.Checked == true)
            {
                if (cb_LoaiMon.SelectedValue != null)
                {
                    check++;
                    if (check >= 2)
                    {
                        query += " AND ";
                    }
                    query += "MON.MALOAI = @MALOAI";
                }
            }
            if (ckbTK_DonGia.Checked == true)
            {
                if (txt_DonGia.Text != "")
                {
                    check++;
                    if (check >= 2)
                        query += " AND ";
                    query += "MON.GIA = @GIA";
                }
                else
                {
                    MessageBox.Show("Bạn chưa nhập đơn giá cần tìm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txt_DonGia.Focus();
                    return;
                }
            }
            if (txt_TenMon.Text != "" || cb_LoaiMon.SelectedValue != null || txt_DonGia.Text != "")
            {
                try
                {
                    SqlParameter[] p =
                    {
                        new SqlParameter("@TENMON","%" + txt_TenMon.Text + "%"),
                        new SqlParameter("@MALOAI",cb_LoaiMon.SelectedValue.ToString()),
                        new SqlParameter("@GIA",txt_DonGia.Text),
                    };
                    dtvgMenu.DataSource = data.GetData(query, p);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        public void LoadMenu_cmbLoaiMon()
        {
            string query = "select MALOAI, TENLOAI from LOAIMON";
            Data dt = new Data();
            cb_LoaiMon.DataSource = dt.GetData(query);
            cb_LoaiMon.DisplayMember = "TENLOAI";
            cb_LoaiMon.ValueMember = "MALOAI";
        }
        private void xoaTrangTextLoaiMon()
        {
            txtMaLoaiMon.Text = "";
            txtTenLoaiMon.Text = "";
            txtTenLoaiMon.Focus();
        }
        private void LoadLoaiMon_dgvLoaiMon()
        {
            string query = "SELECT MALOAI,TENLOAI FROM LOAIMON";
            dgvLoaiMon.DataSource = data.GetData(query);
        }
        private void loadUpdate()
        {
            // load order
            LoadOrder_cmbDanhMuc();
            LoadOrder_cmbDoUong();
            LoadOrder_dgvOrder();
            // loadMenu
            LoadMenu_cmbLoaiMon();
            LoadMenu_dgvMon();

            // Load Loại món
            LoadLoaiMon_dgvLoaiMon();
        }
        private void btnThemLoaiMon_Click(object sender, EventArgs e)
        {
            if (txtTenLoaiMon.Text.Trim() == "")
            {
                MessageBox.Show("Bạn chưa nhập tên loại món! Vui lòng nhập lại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTenLoaiMon.Focus();
                return;
            }
            string query = "INSERT INTO LOAIMON(TENLOAI) VALUES (@TENLOAI)";
            SqlParameter[] p ={
                new SqlParameter("@TENLOAI", txtTenLoaiMon.Text)
            };
            if (data.Excute(query, p))
            {
                xoaTrangTextLoaiMon();
                loadUpdate();
                MessageBox.Show("Thêm loại món thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnSuaLoaiMon_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtMaLoaiMon.Text)) return;
            if (txtTenLoaiMon.Text.Trim() == "")
            {
                MessageBox.Show("Bạn chưa nhập tên loại món! Vui lòng nhập lại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTenLoaiMon.Focus();
                return;
            }
            try
            {
                string query = "UPDATE LOAIMON SET TENLOAI = @TENLOAI WHERE MALOAI = @MALOAI";
                int maloai = int.Parse(txtMaLoaiMon.Text);
                SqlParameter[] p ={
                    new SqlParameter("@TENLOAI", txtTenLoaiMon.Text),
                    new SqlParameter("@MALOAI", maloai)
                };
                if (data.Excute(query, p))
                {
                    xoaTrangTextLoaiMon();
                    loadUpdate();
                    MessageBox.Show("Sửa loại món thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }

        private void btnXoaLoaiMon_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtMaLoaiMon.Text)) return;
            int index = dgvLoaiMon.CurrentCell.RowIndex;
            int maloai = int.Parse(dgvLoaiMon.Rows[index].Cells[0].Value.ToString());

            string query1 = "SELECT COUNT(LOAIMON.MALOAI) FROM LOAIMON " +
                "JOIN MON ON LOAIMON.MALOAI = MON.MALOAI " +
                "JOIN CHITIETHOADON ON MON.MAMON = CHITIETHOADON.MAMON " +
                "JOIN HOADON ON HOADON.MAHOADON = CHITIETHOADON.MAHOADON " +
                "JOIN BAN ON BAN.IDBAN = HOADON.IDBAN " +
                "WHERE HOADON.STATUS = 0 AND LOAIMON.MALOAI = @MaLoai";
            int check = int.Parse(data.Scalar(query1, new SqlParameter("MaLoai", maloai)));
            if (check > 0)
            {
                MessageBox.Show("Có bàn đang đặt loại món này! Chưa thể xoá!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {
                // if (index == -1) return;
                string queryDelCTHD = "DELETE FROM CHITIETHOADON WHERE MAMON in (select MAMON from MON where MALOAI = @MaLoai)";
                if (data.Excute(queryDelCTHD, new SqlParameter("@MaLoai", maloai)))
                {
                    string query = "DELETE FROM LOAIMON WHERE MALOAI = @MALOAI";
                    if (data.Excute(query, new SqlParameter("@MALOAI", maloai)))
                    {
                        xoaTrangTextLoaiMon();
                        loadUpdate();
                        MessageBox.Show("Xoá loại món thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void btnTimKiemLoaiMon_Click(object sender, EventArgs e)
        {
            if (txtTenLoaiMon.Text.Trim() == "")
            {
                MessageBox.Show("Chưa nhập tên loại món! Vui lòng nhập lại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTenLoaiMon.Focus();
                return;
            }
            string query = "SELECT MALOAI,TENLOAI FROM LOAIMON WHERE TENLOAI LIKE @TENLOAI";
            SqlParameter p = new SqlParameter("@TENLOAI", "%" + txtTenLoaiMon.Text + "%");

            dgvLoaiMon.DataSource = data.GetData(query, p);

        }
        private void btnReloadLoaiMon_Click(object sender, EventArgs e)
        {
            xoaTrangTextLoaiMon();
            LoadLoaiMon_dgvLoaiMon();
        }
        private void dgvLoaiMon_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dgvLoaiMon.Rows.Count)
            {
                txtMaLoaiMon.Text = dgvLoaiMon.Rows[e.RowIndex].Cells[0].Value.ToString();
                txtTenLoaiMon.Text = dgvLoaiMon.Rows[e.RowIndex].Cells[1].Value.ToString();

            }
        }
        private void load_TaiKhoan()
        {
            // String query = "SELECT TAIKHOAN, TENHIENTHI,LOAITAIKHOAN FROM TAIKHOAN";
            String query = "SELECT TAIKHOAN.TAIKHOAN, TAIKHOAN.TENHIENTHI, CHUCVU.TENCHUCVU FROM TAIKHOAN " +
                "JOIN CHUCVU ON TAIKHOAN.LOAITAIKHOAN = CHUCVU.MACHUCVU";
            dgvTK.DataSource = data.GetData(query);
        }
        private void phanQuyenUser()
        {
            string query = "SELECT LOAITAIKHOAN FROM TAIKHOAN WHERE TAIKHOAN = @Value1";
            SqlParameter p = new SqlParameter("Value1", taikhoan);
            int value = int.Parse(data.Scalar(query, p));
            if (value == 1)
            {
                EnableDisableControlsInTabPage(tabControl1.TabPages[1], false);
                EnableDisableControlsInTabPage(tabControl1.TabPages[2], false);
                EnableDisableControlsInTabPage(tabControl1.TabPages[3], false);
                btnXoaTK_tabTK.Enabled = false;
                btnSuaThongTin_TabTK.Enabled = false;
                cmbChucVu_tabTaiKhoan.Enabled = false;
            }
            else
            {
                EnableDisableControlsInTabPage(tabControl1.TabPages[1], true);
                EnableDisableControlsInTabPage(tabControl1.TabPages[2], true);
                EnableDisableControlsInTabPage(tabControl1.TabPages[3], true);
                btnXoaTK_tabTK.Enabled = true;
                btnSuaThongTin_TabTK.Enabled = true;
                cmbChucVu_tabTaiKhoan.Enabled = true;

            }
        }
        private void Coffee_Load(object sender, EventArgs e)
        {
            Original_Font();
            data = new Data();
            // order
            LoadOrder_cmbDanhMuc();
            LoadOrder_cmbDoUong();
            cbox_Chuyenban_Load();
            cboxDanhmucTenban_Load();
            LoadOrder_dgvOrder();
            check_Order_Load();
            // menu
            LoadMenu_cmbLoaiMon();
            LoadMenu_dgvMon();
            // ẩn nút tìm kiếm
            btn_TimKiemMenu.Enabled = false;
            // loại món
            LoadLoaiMon_dgvLoaiMon();
            // tài khoản
            load_TaiKhoan();
            phanQuyenUser();
            LoadTaiKhoan_cmbChucVu();

        }
        private void EnableDisableControlsInTabPage(TabPage tabPage, bool enable)
        {
            foreach (Control control in tabPage.Controls)
            {
                control.Enabled = enable;
            }
        }
        private void btnDangXuat_Click(object sender, EventArgs e)
        {
            DialogResult a = MessageBox.Show("Chắc chắn muốn đăng xuất?", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (a == DialogResult.OK)
            {
                loginform.Show();
                loginform.FormClosed += (s, args) => this.Close();
                this.Hide();
            }
        }
        /*
        private void btnDangXuat_Click(object sender, EventArgs e)
        {
            loginform.Show();
            loginform.FormClosed += (s, args) => this.Close();
            this.Hide();
        }
        */

        void SetImage(int i)
        {
            String path = System.IO.Directory.GetCurrentDirectory();
            switch (i)
            {
                case 1: btn1.BackgroundImage = Image.FromFile(path + @"\Cup.png"); break;
                case 2: btn2.BackgroundImage = Image.FromFile(path + @"\Cup.png"); break;
                case 3: btn3.BackgroundImage = Image.FromFile(path + @"\Cup.png"); break;
                case 4: btn4.BackgroundImage = Image.FromFile(path + @"\Cup.png"); break;
                case 5: btn5.BackgroundImage = Image.FromFile(path + @"\Cup.png"); break;
                case 6: btn6.BackgroundImage = Image.FromFile(path + @"\Cup.png"); break;
                case 7: btn7.BackgroundImage = Image.FromFile(path + @"\Cup.png"); break;
                case 8: btn8.BackgroundImage = Image.FromFile(path + @"\Cup.png"); break;
                case 9: btn9.BackgroundImage = Image.FromFile(path + @"\Cup.png"); break;
                case 10: btn10.BackgroundImage = Image.FromFile(path + @"\Cup.png"); break;
                case 11: btn11.BackgroundImage = Image.FromFile(path + @"\Cup.png"); break;
                case 12: btn12.BackgroundImage = Image.FromFile(path + @"\Cup.png"); break;
                case 13: btn13.BackgroundImage = Image.FromFile(path + @"\Cup.png"); break;
                case 14: btn14.BackgroundImage = Image.FromFile(path + @"\Cup.png"); break;
                case 15: btn15.BackgroundImage = Image.FromFile(path + @"\Cup.png"); break;
                case 16: btn16.BackgroundImage = Image.FromFile(path + @"\Cup.png"); break;
            }
        }
        void NoneImage(int i)
        {
            switch (i)
            {
                case 1: btn1.BackgroundImage = null; break;
                case 2: btn2.BackgroundImage = null; break;
                case 3: btn3.BackgroundImage = null; break;
                case 4: btn4.BackgroundImage = null; break;
                case 5: btn5.BackgroundImage = null; break;
                case 6: btn6.BackgroundImage = null; break;
                case 7: btn7.BackgroundImage = null; break;
                case 8: btn8.BackgroundImage = null; break;
                case 9: btn9.BackgroundImage = null; break;
                case 10: btn10.BackgroundImage = null; break;
                case 11: btn11.BackgroundImage = null; break;
                case 12: btn12.BackgroundImage = null; break;
                case 13: btn13.BackgroundImage = null; break;
                case 14: btn14.BackgroundImage = null; break;
                case 15: btn15.BackgroundImage = null; break;
                case 16: btn16.BackgroundImage = null; break;
            }
        }
        void Original_Font()
        {
            this.btn1.Font = new Font(this.btn1.Font.FontFamily, 13, FontStyle.Regular);
            this.btn2.Font = new Font(this.btn2.Font.FontFamily, 13, FontStyle.Regular);
            this.btn3.Font = new Font(this.btn3.Font.FontFamily, 13, FontStyle.Regular);
            this.btn4.Font = new Font(this.btn4.Font.FontFamily, 13, FontStyle.Regular);
            this.btn5.Font = new Font(this.btn5.Font.FontFamily, 13, FontStyle.Regular);
            this.btn6.Font = new Font(this.btn6.Font.FontFamily, 13, FontStyle.Regular);
            this.btn7.Font = new Font(this.btn7.Font.FontFamily, 13, FontStyle.Regular);
            this.btn8.Font = new Font(this.btn8.Font.FontFamily, 13, FontStyle.Regular);
            this.btn9.Font = new Font(this.btn9.Font.FontFamily, 13, FontStyle.Regular);
            this.btn10.Font = new Font(this.btn10.Font.FontFamily, 13, FontStyle.Regular);
            this.btn11.Font = new Font(this.btn11.Font.FontFamily, 13, FontStyle.Regular);
            this.btn12.Font = new Font(this.btn12.Font.FontFamily, 13, FontStyle.Regular);
            this.btn13.Font = new Font(this.btn13.Font.FontFamily, 13, FontStyle.Regular);
            this.btn14.Font = new Font(this.btn14.Font.FontFamily, 13, FontStyle.Regular);
            this.btn15.Font = new Font(this.btn15.Font.FontFamily, 13, FontStyle.Regular);
            this.btn16.Font = new Font(this.btn15.Font.FontFamily, 13, FontStyle.Regular);

            this.btn1.BackColor = Color.White;
            this.btn2.BackColor = Color.White;
            this.btn3.BackColor = Color.White;
            this.btn4.BackColor = Color.White;
            this.btn5.BackColor = Color.White;
            this.btn6.BackColor = Color.White;
            this.btn7.BackColor = Color.White;
            this.btn8.BackColor = Color.White;
            this.btn9.BackColor = Color.White;
            this.btn10.BackColor = Color.White;
            this.btn11.BackColor = Color.White;
            this.btn12.BackColor = Color.White;
            this.btn13.BackColor = Color.White;
            this.btn14.BackColor = Color.White;
            this.btn15.BackColor = Color.White;
            this.btn16.BackColor = Color.White;
        }
        void Pick_Font(Button btn)
        {
            btn.Font = new Font(this.btn1.Font.FontFamily, 15, FontStyle.Bold);
            btn.BackColor = Color.FromArgb(255, 224, 192);
        }
        private void Coffee_SizeChanged(object sender, EventArgs e)
        {
            int x = this.Size.Width;
            int y = this.Size.Height;
            this.tabControl1.Size = new Size(x, y);
        }

        private void cboxDanhmucTenban_SelectedIndexChanged(object sender, EventArgs e)
        {
            Original_Font();
            switch (this.cboxDanhmucTenban.SelectedIndex)
            {
                case 0: Pick_Font(btn1); break;
                case 1: Pick_Font(btn2); break;
                case 2: Pick_Font(btn3); break;
                case 3: Pick_Font(btn4); break;
                case 4: Pick_Font(btn5); break;
                case 5: Pick_Font(btn6); break;
                case 6: Pick_Font(btn7); break;
                case 7: Pick_Font(btn8); break;
                case 8: Pick_Font(btn9); break;
                case 9: Pick_Font(btn10); break;
                case 10: Pick_Font(btn11); break;
                case 11: Pick_Font(btn12); break;
                case 12: Pick_Font(btn13); break;
                case 13: Pick_Font(btn14); break;
                case 14: Pick_Font(btn15); break;
                case 15: Pick_Font(btn16); break;
            }
            slOrder.Value = 1;
        }
        private void txtThanhToan_Load()
        {
            String s = data.Scalar("SELECT THANHTIEN FROM HOADON WHERE " +
                "IDBAN = @idban AND STATUS = 0", new SqlParameter("@idban", cboxDanhmucTenban.SelectedValue));
            var culture = new CultureInfo("en-US");
            culture.NumberFormat.NumberDecimalSeparator = ",";
            culture.NumberFormat.NumberGroupSeparator = ".";
            double amount = Convert.ToDouble(s);
            txtThanhToan.Text = (String.IsNullOrEmpty(s)) ? "0,00 VNĐ" : amount.ToString("N", culture) + " VNĐ";
        }
        private void LoadOrder_dgvOrder()
        {
            String query = "SELECT MON.MAMON, TENMON, SOLUONG, SOLUONG * MON.GIA AS THANHTIEN " +
                "FROM CHITIETHOADON JOIN MON ON CHITIETHOADON.MAMON = MON.MAMON " +
                "JOIN HOADON ON HOADON.MAHOADON = CHITIETHOADON.MAHOADON WHERE IDBAN = @idban AND STATUS = 0";
            dgvOrder.DataSource = data.GetData(query, new SqlParameter("@idban", cboxDanhmucTenban.SelectedValue));
            txtThanhToan_Load();
        }
        private void LoadOrder_cmbDanhMuc()
        {
            cboxDanhmucOrder.DataSource = null;
            cboxDanhmucOrder.ValueMember = "MALOAI";
            cboxDanhmucOrder.DisplayMember = "TENLOAI";
            cboxDanhmucOrder.DataSource = data.GetData("SELECT MALOAI,TENLOAI FROM LOAIMON");

        }
        private void cbox_Chuyenban_Load()
        {
            cbox_Chuyenban.DataSource = null;
            cbox_Chuyenban.DataSource = data.GetData("SELECT * FROM BAN WHERE STATUS = 0");
            cbox_Chuyenban.DisplayMember = "IDBAN";
            cbox_Chuyenban.ValueMember = "IDBAN";
        }
        private void LoadOrder_cmbDoUong()
        {
            cboxDouong.DataSource = null;
            if (cboxDanhmucOrder.SelectedValue == null) return;
            cboxDouong.DisplayMember = "TENMON";
            cboxDouong.ValueMember = "MAMON";
            cboxDouong.DataSource = data.GetData("SELECT * FROM MON WHERE MALOAI = @maloai", new SqlParameter("@maloai", cboxDanhmucOrder.SelectedValue.ToString()));
            slOrder.Value = 1;
        }
        void check_Order_Load()
        {
            using (SqlConnection sqlCon = new SqlConnection(data.GetStringConnection()))
            {
                sqlCon.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM BAN WHERE STATUS = 1", sqlCon))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            switch (Convert.ToInt32(reader["IDBAN"]))
                            {
                                case 1: SetImage(1); break;
                                case 2: SetImage(2); break;
                                case 3: SetImage(3); break;
                                case 4: SetImage(4); break;
                                case 5: SetImage(5); break;
                                case 6: SetImage(6); break;
                                case 7: SetImage(7); break;
                                case 8: SetImage(8); break;
                                case 9: SetImage(9); break;
                                case 10: SetImage(10); break;
                                case 11: SetImage(11); break;
                                case 12: SetImage(12); break;
                                case 13: SetImage(13); break;
                                case 14: SetImage(14); break;
                                case 15: SetImage(15); break;
                                case 16: SetImage(16); break;
                            }
                        }
                    }
                }
            }
        }
        private void cboxDanhmucTenban_Load()
        {
            cboxDanhmucTenban.DataSource = null;
            cboxDanhmucTenban.DataSource = data.GetData("SELECT * FROM BAN");
            cboxDanhmucTenban.DisplayMember = "IDBAN";
            cboxDanhmucTenban.ValueMember = "IDBAN";
        }
        private void btn1_Click(object sender, EventArgs e)
        {
            cboxDanhmucTenban.SelectedIndex = 0;
            LoadOrder_dgvOrder();
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            cboxDanhmucTenban.SelectedIndex = 1;
            LoadOrder_dgvOrder();
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            cboxDanhmucTenban.SelectedIndex = 2;
            LoadOrder_dgvOrder();
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            cboxDanhmucTenban.SelectedIndex = 3;
            LoadOrder_dgvOrder();
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            cboxDanhmucTenban.SelectedIndex = 4;
            LoadOrder_dgvOrder();
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            cboxDanhmucTenban.SelectedIndex = 5;
            LoadOrder_dgvOrder();
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            cboxDanhmucTenban.SelectedIndex = 6;
            LoadOrder_dgvOrder();
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            cboxDanhmucTenban.SelectedIndex = 7;
            LoadOrder_dgvOrder();
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            cboxDanhmucTenban.SelectedIndex = 8;
            LoadOrder_dgvOrder();
        }

        private void btn10_Click(object sender, EventArgs e)
        {
            cboxDanhmucTenban.SelectedIndex = 9;
            LoadOrder_dgvOrder();
        }

        private void btn11_Click(object sender, EventArgs e)
        {
            cboxDanhmucTenban.SelectedIndex = 10;
            LoadOrder_dgvOrder();
        }

        private void btn12_Click(object sender, EventArgs e)
        {
            cboxDanhmucTenban.SelectedIndex = 11;
            LoadOrder_dgvOrder();
        }

        private void btn13_Click(object sender, EventArgs e)
        {
            cboxDanhmucTenban.SelectedIndex = 12;
            LoadOrder_dgvOrder();
        }

        private void btn14_Click(object sender, EventArgs e)
        {
            cboxDanhmucTenban.SelectedIndex = 13;
            LoadOrder_dgvOrder();
        }

        private void btn15_Click(object sender, EventArgs e)
        {
            cboxDanhmucTenban.SelectedIndex = 14;
            LoadOrder_dgvOrder();
        }

        private void btn16_Click(object sender, EventArgs e)
        {
            cboxDanhmucTenban.SelectedIndex = 15;
            LoadOrder_dgvOrder();
        }

        private void cboxDanhmucOrder_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadOrder_cmbDoUong();
        }


        private void QRCode_Click(object sender, EventArgs e)
        {
            fQR qr = new fQR(); ;
            qr.ShowDialog();
        }

        private void btnThemMon_Click(object sender, EventArgs e)
        {
            try
            {
                if (cboxDanhmucOrder.SelectedValue == null || cboxDouong.SelectedValue == null) return;
                // Kiểm tra có hoá đơn của bàn này chưa, lấy mã hoá đơn
                String s = data.Scalar("SELECT MAHOADON FROM HOADON WHERE IDBAN = @idban AND STATUS = 0",
                    new SqlParameter("@idban", cboxDanhmucTenban.SelectedValue));
                // Lấy giá của món đang đặt trong cbox
                float gia = float.Parse(data.Scalar("SELECT GIA FROM MON WHERE MAMON = @mamon",
                        new SqlParameter("@mamon", cboxDouong.SelectedValue)));
                // Lấy mã món đang đặt cbox
                String mamon = data.Scalar("SELECT MAMON FROM MON WHERE MAMON = @mamon",
                    new SqlParameter("@mamon", cboxDouong.SelectedValue));
                //Chưa có thì thêm vào hoá đơn
                if (String.IsNullOrEmpty(s))
                {
                    SqlParameter[] args =
                    {
                        new SqlParameter("@taikhoan", taikhoan),
                        new SqlParameter("@date", DateTime.Now.ToString("yyyy-MM-dd")),
                        new SqlParameter("@idban", cboxDanhmucTenban.SelectedValue),
                        new SqlParameter("@thanhtien", gia * float.Parse(slOrder.Value.ToString())),
                        new SqlParameter("@status", "0")
                    };
                    String query = "INSERT INTO HOADON VALUES (@taikhoan, @date, @idban, @thanhtien, @status)";
                    if (data.Excute(query, args))
                    {
                        // Lấy mã hoá đơn để thêm vào chi tiết hoá đơn
                        String mahoadon = data.Scalar("SELECT * FROM HOADON ORDER BY MAHOADON DESC");
                        query = "INSERT INTO CHITIETHOADON VALUES (@mahoadon, @mamon, @soluong)";
                        SqlParameter[] p =
                        {
                            new SqlParameter("@mahoadon", mahoadon),
                            new SqlParameter("@mamon", mamon),
                            new SqlParameter("@soluong", slOrder.Value)
                        };
                        // Đặt status của bàn là 1 để biết có khách
                        if (data.Excute(query, p)) LoadOrder_dgvOrder();
                        query = "UPDATE BAN " +
                            "SET STATUS = 1 " +
                            "WHERE IDBAN = @idban";
                        if (data.Excute(query, new SqlParameter("@idban", cboxDanhmucTenban.SelectedValue)))
                        {
                            cbox_Chuyenban_Load();
                            SetImage(cboxDanhmucTenban.SelectedIndex + 1);
                            cbox_Chuyenban_Load();
                        }
                    }

                }
                // Có rồi thì update lại tổng bill
                else
                {
                    String query = "UPDATE HOADON " +
                        "SET THANHTIEN = THANHTIEN + @thanhtien " +
                        "WHERE MAHOADON = @mahoadon";
                    SqlParameter[] args =
                    {
                        new SqlParameter("@thanhtien", gia * float.Parse(slOrder.Value.ToString())),
                        new SqlParameter("@mahoadon", s)
                    };
                    if (data.Excute(query, args))
                    {
                        // Kiểm tra xem món đang thêm tồn tại chưa
                        String update_chitiet = data.Scalar("SELECT * FROM CHITIETHOADON WHERE MAHOADON = @mahoadon " +
                            "AND MAMON = @mamon", new SqlParameter("@mahoadon", s), new SqlParameter("@mamon", mamon));
                        // Chưa có thì thêm
                        if (String.IsNullOrEmpty(update_chitiet))
                        {
                            query = "INSERT INTO CHITIETHOADON VALUES (@mahoadon, @mamon, @soluong)";
                        }
                        // Có rồi thì update số lượng
                        else
                        {
                            query = "UPDATE CHITIETHOADON" +
                                " SET SOLUONG = SOLUONG + @soluong" +
                                " WHERE MAHOADON = @mahoadon AND" +
                                " MAMON = @mamon";
                        }
                        SqlParameter[] p =
                        {
                            new SqlParameter("@mahoadon", s),
                            new SqlParameter("@mamon", mamon),
                            new SqlParameter("@soluong", slOrder.Value)
                        };
                        if (data.Excute(query, p))
                        {
                            LoadOrder_dgvOrder();
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                // Nếu ko chọn cell nào hoặc cell rỗng thì dừng
                if (dgvOrder.SelectedCells.Count < 1 || dgvOrder.SelectedCells[0].Value == null) return;
                // Lấy mã hoá đơn, mã món định xoá, giá của món, số lượng của món trong chi tiết
                String s = data.Scalar("SELECT MAHOADON FROM HOADON WHERE IDBAN = @idban AND STATUS = 0",
                    new SqlParameter("@idban", cboxDanhmucTenban.SelectedValue));
                String mamon = data.Scalar("SELECT MAMON FROM MON WHERE MAMON = @mamon",
                    new SqlParameter("@mamon", dgvOrder.Rows[dgvOrder.SelectedCells[0].RowIndex].Cells[0].Value));
                float gia = float.Parse(data.Scalar("SELECT GIA FROM MON WHERE MAMON = @mamon",
                    new SqlParameter("@mamon", mamon)));
                int soluong = int.Parse(data.Scalar("SELECT SOLUONG FROM CHITIETHOADON WHERE MAHOADON = @mahoadon "
                    + "AND MAMON = @mamon",
                    new SqlParameter("@mahoadon", s),
                    new SqlParameter("@mamon", mamon)));
                // Xoá món ở trong chi tiết
                String query = "DELETE FROM CHITIETHOADON WHERE MAHOADON = @mahoadon " +
                    "AND MAMON = @mamon";
                SqlParameter[] args =
                {
                    new SqlParameter("@mahoadon", s),
                    new SqlParameter("@mamon", mamon)
                };
                if (data.Excute(query, args))
                {
                    // Update lại tổng bill
                    query = "UPDATE HOADON " +
                        "SET THANHTIEN = THANHTIEN - @thanhtien " +
                        "WHERE MAHOADON = @mahoadon";
                    SqlParameter[] p =
                    {
                        new SqlParameter("@thanhtien", (float)soluong*gia),
                        new SqlParameter("@mahoadon", s)
                    };
                    if (data.Excute(query, p)) LoadOrder_dgvOrder();
                    // 0,00 tức bàn ko có ai đặt thì xoá hoá đơn
                    if (txtThanhToan.Text == "0,00 VNĐ")
                    {
                        query = "DELETE FROM HOADON WHERE MAHOADON = @mahoadon";
                        data.Excute(query, new SqlParameter("@mahoadon", s));
                    }
                    query = "UPDATE BAN SET STATUS = 0 WHERE IDBAN = @idban";
                    if (data.Excute(query, new SqlParameter("@idban", cboxDanhmucTenban.SelectedValue))) NoneImage(cboxDanhmucTenban.SelectedIndex + 1);
                    cbox_Chuyenban_Load();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnChuyenban_Click(object sender, EventArgs e)
        {
            try
            {
                // Order rỗng thì thôi
                if (dgvOrder.Rows.Count <= 1) return;
                String mahoadon = data.Scalar("SELECT MAHOADON FROM HOADON WHERE IDBAN = @idban AND STATUS = 0",
                    new SqlParameter("@idban", cboxDanhmucTenban.SelectedValue));
                // Chuyển id bàn sang bàn rỗng
                String query = "UPDATE HOADON " +
                    "SET IDBAN = @idban " +
                    "WHERE MAHOADON = @mahoadon";
                if (data.Excute(query,
                    new SqlParameter("@idban", cbox_Chuyenban.SelectedValue),
                    new SqlParameter("@mahoadon", mahoadon)))
                {
                    // Sửa status của 2 bàn cho nhau
                    query = "UPDATE BAN " +
                        "SET STATUS = 1 " +
                        "WHERE IDBAN = @idban";
                    data.Excute(query, new SqlParameter("@idban", cbox_Chuyenban.SelectedValue));
                    query = "UPDATE BAN " +
                        "SET STATUS = 0 " +
                        "WHERE IDBAN = @idban";
                    data.Excute(query, new SqlParameter("@idban", cboxDanhmucTenban.SelectedValue));
                    SetImage(Convert.ToInt32(cbox_Chuyenban.SelectedValue));
                    NoneImage(cboxDanhmucTenban.SelectedIndex + 1);
                    LoadOrder_dgvOrder();
                    cbox_Chuyenban_Load();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void printDoc_Hoadon_PrintPage(object sender, PrintPageEventArgs e)
        {
            StringFormat format = new StringFormat();
            format.LineAlignment = StringAlignment.Center;
            format.Alignment = StringAlignment.Center;

            // Vẽ tiêu đề hoá đơn
            Font font = new Font("Calibri", 20, FontStyle.Bold);
            e.Graphics.DrawString("HÓA ĐƠN COFFEE", font, Brushes.Black, new RectangleF(0, 0, e.PageBounds.Width, 50), format);
            font = new Font("Calibri", 15);

            // Vẽ thông tin khách hàng
            format.Alignment = StringAlignment.Near;
            String mahoadon = data.Scalar("SELECT MAHOADON FROM HOADON WHERE IDBAN = @idban AND STATUS = 0",
                    new SqlParameter("@idban", cboxDanhmucTenban.SelectedValue));
            e.Graphics.DrawString("Tài khoản: " + taikhoan + " - " + data.Scalar(" select tenhienthi from taikhoan where taikhoan = @tk", new SqlParameter("@tk", taikhoan)), font, Brushes.Black, new PointF(50, 80));
            e.Graphics.DrawString("Hoá đơn: " + mahoadon, font, Brushes.Black, new PointF(50, 110));
            String tenban = "Tên bàn: " + this.cboxDanhmucTenban.SelectedValue + " - " + DateTime.Now.ToString();
            e.Graphics.DrawString(tenban, font, Brushes.Black, new PointF(50, 140));
            e.Graphics.DrawString("Địa chỉ: Tú Sơn - Kiến Thụy - Hải Phòng", font, Brushes.Black, new PointF(50, 170));

            // Vẽ bảng giá
            int x = 50;
            int y = 250;
            int rowHeight = 30;

            e.Graphics.DrawLine(Pens.Black, x, y, x + 700, y);

            e.Graphics.DrawString("Tên món", font, Brushes.Black, new RectangleF(x, y, 300, rowHeight), format);
            e.Graphics.DrawString("Số lượng", font, Brushes.Black, new RectangleF(x + 300, y, 100, rowHeight), format);
            e.Graphics.DrawString("Đơn giá", font, Brushes.Black, new RectangleF(x + 450, y, 300, rowHeight), format);

            y += rowHeight;
            e.Graphics.DrawLine(Pens.Black, x, y, x + 700, y);
            //Lấy dữ liệu
            foreach (DataGridViewRow row in dgvOrder.Rows)
            {
                if (row.IsNewRow)
                {
                    continue;
                }

                string productName = row.Cells[1].Value.ToString();
                int quantity = Convert.ToInt32(row.Cells[2].Value);
                decimal unitPrice = Convert.ToDecimal(row.Cells[3].Value);

                e.Graphics.DrawString(productName, font, Brushes.Black, new RectangleF(x, y, 300, rowHeight), format);
                e.Graphics.DrawString(quantity.ToString(), font, Brushes.Black, new RectangleF(x + 300, y, 100, rowHeight), format);
                e.Graphics.DrawString(unitPrice.ToString("N0"), font, Brushes.Black, new RectangleF(x + 450, y, 300, rowHeight), format);

                y += rowHeight;
            }

            e.Graphics.DrawLine(Pens.Black, x, y, x + 700, y);
            // Vẽ tổng cộng
            y += rowHeight;
            e.Graphics.DrawString("Tổng tiền: " + txtThanhToan.Text, new Font("Calibri", 16, FontStyle.Bold), Brushes.Black, new RectangleF(x, y, e.PageBounds.Width, 50), format);
            y += rowHeight;
            // Vẽ cảm ơn
            e.Graphics.DrawString("Cảm ơn vì đã tin tưởng dịch vụ của chúng tôi!!!", new Font("Calibri", 10), Brushes.Black, new RectangleF(x, y, e.PageBounds.Width, 50), format);

            // Giải phóng bộ nhớ
            font.Dispose();
            format.Dispose();
        }

        private void btnThanhToan_Click(object sender, EventArgs e)
        {
            if (dgvOrder.Rows.Count <= 1) return;
            PrintDocument printDocument = new PrintDocument();
            printDocument.PrintPage += new PrintPageEventHandler(printDoc_Hoadon_PrintPage);

            PrintPreviewDialog printPreviewDialog = new PrintPreviewDialog();
            printPreviewDialog.Document = printDocument;

            // Mở cửa sổ xem trước
            printPreviewDialog.ShowDialog();
            // Lấy mã hoá đơn để đặt status thanh toán về 1 - đã thanh toán
            String mahoadon = data.Scalar("SELECT MAHOADON FROM HOADON WHERE IDBAN = @idban AND STATUS = 0",
                    new SqlParameter("@idban", cboxDanhmucTenban.SelectedValue));
            String query = "UPDATE HOADON " +
                "SET STATUS = 1 " +
                "WHERE MAHOADON = @mahoadon";
            data.Excute(query, new SqlParameter("@mahoadon", mahoadon));
            // Đưa status của bàn vừa thanh toán về 0 - Chưa có người
            query = "UPDATE BAN " +
                "SET STATUS = 0 " +
                "WHERE IDBAN = @idban";
            data.Excute(query, new SqlParameter("@idban", cboxDanhmucTenban.SelectedValue));
            LoadOrder_dgvOrder();
            cbox_Chuyenban_Load();
            NoneImage(cboxDanhmucTenban.SelectedIndex + 1);
        }


        private void cb_LoaiMon_SelectedValueChanged(object sender, EventArgs e)
        {
            // LoadMenu_dgvMon();
            //txt_MaMon.Clear();
            //txt_TenMon.Clear(); 
            //txt_DonGia.Clear();
        }

        private void txt_DonGia_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) || (e.KeyChar == ' '))
            {
                e.Handled = true;
            }
        }

        public void XoaTrangMenu()
        {
            txt_MaMon.Clear();
            txt_TenMon.Clear();
            txt_DonGia.Clear();
            txt_TenMon.Focus();
        }

        private void btnXoaTK_Click(object sender, EventArgs e)
        {
            if (dgvTK.SelectedCells.Count > 0)
            {
                DataGridViewCell selected = dgvTK.SelectedCells[0];
                int rowIndex = selected.RowIndex;
                if (rowIndex < 0 || rowIndex >= dgvTK.RowCount)
                {
                    MessageBox.Show("Vui lòng chọn tài khoản bạn muốn xoá", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    DialogResult result = MessageBox.Show("Bạn có muốn xoá tài khoản này không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        string query = "DELETE FROM TAIKHOAN WHERE TAIKHOAN = @Value1";
                        SqlParameter p = new SqlParameter("@Value1", dgvTK.Rows[rowIndex].Cells[0].Value.ToString());
                        if (data.Excute(query, p))
                        {
                            MessageBox.Show("Xoá tài khoản thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
                load_TaiKhoan();
            }
            else
            {
                MessageBox.Show("Vui lòng chọn tài khoản muốn đổi mật khẩu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_ThemMenu_Click(object sender, EventArgs e)
        {
            if (txt_TenMon.Text == "")
            {
                MessageBox.Show("Chưa nhập tên món", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_TenMon.Focus();
                return;
            }
            if (txt_DonGia.Text == "")
            {
                MessageBox.Show("Chưa nhập giá của món", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_DonGia.Focus();
                return;
            }
            string query = "insert into MON(TENMON, MALOAI, GIA) values(@TENMON, @MALOAI, @GIA)";
            SqlParameter[] p = {
                new SqlParameter("@TENMON", txt_TenMon.Text),
                new SqlParameter("@MALOAI", cb_LoaiMon.SelectedValue.ToString()),
                new SqlParameter("@GIA", txt_DonGia.Text)
            };
            data = new Data();
            if (data.Excute(query, p))
            {
                MessageBox.Show("Thêm món thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                XoaTrangMenu();
                loadUpdate();
            }

        }

        private void btn_XoaMenu_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txt_MaMon.Text)) return;
            if (dtvgMenu.SelectedCells.Count > 0 && dtvgMenu.CurrentCell != null)
            {

                int rowIndex = dtvgMenu.CurrentCell.RowIndex;
                int MAMON = (int)dtvgMenu.Rows[rowIndex].Cells["MaMonMenu"].Value;
                string query1 = "SELECT COUNT(MON.MAMON) FROM MON " +
                "JOIN CHITIETHOADON ON MON.MAMON = CHITIETHOADON.MAMON " +
                "JOIN HOADON ON HOADON.MAHOADON = CHITIETHOADON.MAHOADON " +
                "WHERE HOADON.STATUS = 0 AND MON.MAMON = @MaMon";
                int check = int.Parse(data.Scalar(query1, new SqlParameter("MaMon", MAMON)));
                if (check > 0)
                {
                    MessageBox.Show("Có bàn đang đặt món này! Chưa thể xoá!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string query = "delete from MON where MAMON = @MAMON";
                if (data.Excute(query, new SqlParameter("MAMON", MAMON)))
                {
                    MessageBox.Show("Xoá món thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    XoaTrangMenu();
                    loadUpdate();
                }
            }
        }



        private void btn_SuaMenu_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txt_MaMon.Text)) return;
            if (txt_TenMon.Text.Trim() == "")
            {
                MessageBox.Show("Bạn chưa nhập tên món! Vui lòng nhập lại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_TenMon.Focus();
                return;
            }
            if (txt_DonGia.Text.Trim() == "0" || txt_DonGia.Text.Trim() == "")
            {
                MessageBox.Show("Đơn giá phải > 0! Vui lòng nhập lại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_DonGia.Focus();
                return;
            }
            int rowIndex = dtvgMenu.CurrentCell.RowIndex;
            int MAMON = (int)dtvgMenu.Rows[rowIndex].Cells["MaMonMenu"].Value;
            string query1 = "SELECT COUNT(MON.MAMON) FROM MON " +
            "JOIN CHITIETHOADON ON MON.MAMON = CHITIETHOADON.MAMON " +
            "JOIN HOADON ON HOADON.MAHOADON = CHITIETHOADON.MAHOADON " +
            "WHERE HOADON.STATUS = 0 AND MON.MAMON = @MaMon";
            int check = int.Parse(data.Scalar(query1, new SqlParameter("MaMon", MAMON)));
            if (check > 0)
            {
                MessageBox.Show("Có bàn đang đặt món này! Chưa thể sửa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string query = "update MON set TENMON = @TENMON, MALOAI = @MALOAI, GIA = @GIA where MAMON = @MAMON";
            SqlParameter[] p =
            {
                    new SqlParameter("@MAMON", MAMON), new SqlParameter("@TENMON", txt_TenMon.Text), new SqlParameter("@MALOAI", cb_LoaiMon.SelectedValue.ToString()),
                    new SqlParameter("@GIA", txt_DonGia. Text),
                };
            data = new Data();
            if (data.Excute(query, p))
            {
                XoaTrangMenu();
                loadUpdate();
                MessageBox.Show("Sửa món thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void btn_ReLoad_Click(object sender, EventArgs e)
        {
            txt_MaMon.Clear();
            txt_TenMon.Clear();
            txt_DonGia.Clear();
            txt_TenMon.Focus();
            cb_LoaiMon.SelectedIndex = 0;
            LoadMenu_dgvMon();
        }




        private void btnTaoTK_tabTK_Click(object sender, EventArgs e)
        {
            fTaoTaiKhoan t = new fTaoTaiKhoan();
            t.ShowDialog();
            load_TaiKhoan();
        }

        private void btnDoiMK_tabTK_Click(object sender, EventArgs e)
        {
            if (dgvTK.SelectedCells.Count > 0)
            {
                DataGridViewCell selectedCell = dgvTK.SelectedCells[0];
                int rowIndex = selectedCell.RowIndex;
                string query = "SELECT TAIKHOAN FROM TAIKHOAN WHERE TAIKHOAN = @Value1";
                SqlParameter p = new SqlParameter("@Value1", dgvTK.Rows[rowIndex].Cells[0].Value.ToString());
                string cellValue = data.Scalar(query, p);
                DoiMatKhau doiMatKhau = new DoiMatKhau(cellValue);
                doiMatKhau.ShowDialog();
            }
            else
            {
                MessageBox.Show("Vui lòng chọn tài khoản muốn đổi mật khẩu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXoaTK_tabTK_Click(object sender, EventArgs e)
        {
            if (dgvTK.SelectedCells.Count > 0)
            {
                DataGridViewCell selected = dgvTK.SelectedCells[0];
                int rowIndex = selected.RowIndex;

                if (dgvTK.Rows[rowIndex].Cells[0].Value.ToString() == "admin")
                {
                    MessageBox.Show("Không thể xoá tài khoản admin!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                DialogResult result = MessageBox.Show("Bạn có muốn xoá tài khoản này không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    string query = "DELETE FROM TAIKHOAN WHERE TAIKHOAN = @Value1";
                    SqlParameter p = new SqlParameter("@Value1", dgvTK.Rows[rowIndex].Cells[0].Value.ToString());
                    if (data.Excute(query, p))
                    {
                        MessageBox.Show("Xoá tài khoản thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtTaiKhoan_tabTaiKhoan.Clear();
                        txtTenHienThi_tabTaiKhoan.Clear();
                        if (cmbChucVu_tabTaiKhoan.Items.Count > 0)
                            cmbChucVu_tabTaiKhoan.SelectedIndex = 0;
                    }
                }
                load_TaiKhoan();
            }
            else
            {
                MessageBox.Show("Vui lòng chọn tài khoản muốn xoá", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void LoadTaiKhoan_cmbChucVu()
        {
            string query = "SELECT MACHUCVU, TENCHUCVU FROM CHUCVU";

            cmbChucVu_tabTaiKhoan.DataSource = data.GetData(query);
            cmbChucVu_tabTaiKhoan.ValueMember = "MACHUCVU";
            cmbChucVu_tabTaiKhoan.DisplayMember = "TENCHUCVU";
        }
        private void dgvTK_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                txtTaiKhoan_tabTaiKhoan.Text = dgvTK.Rows[e.RowIndex].Cells[0].Value.ToString();
                txtTenHienThi_tabTaiKhoan.Text = dgvTK.Rows[e.RowIndex].Cells[1].Value.ToString();
                cmbChucVu_tabTaiKhoan.Text = dgvTK.Rows[e.RowIndex].Cells[2].Value.ToString();
            }
        }

        private void btnSuaThongTin_TabTK_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtTaiKhoan_tabTaiKhoan.Text)) return;
            if (txtTenHienThi_tabTaiKhoan.Text.Trim() == "")
            {
                MessageBox.Show("Bạn chưa nhập tên hiển thị!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTenHienThi_tabTaiKhoan.Focus();
                return;
            }
            string query = "UPDATE TAIKHOAN " +
                "SET TENHIENTHI = @TENHIENTHI,LOAITAIKHOAN = @LOAITAIKHOAN " +
                "WHERE TAIKHOAN = @TAIKHOAN";
            SqlParameter[] p =
            {
                new SqlParameter("@TENHIENTHI",txtTenHienThi_tabTaiKhoan.Text),
                new SqlParameter("@LOAITAIKHOAN",cmbChucVu_tabTaiKhoan.SelectedValue),
                new SqlParameter("@TAIKHOAN",txtTaiKhoan_tabTaiKhoan.Text),
            };

            if (data.Excute(query, p))
            {
                MessageBox.Show("Sửa thông tin tài khoản thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            load_TaiKhoan();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (ckbTK_DonGia.Checked == false && ckbTK_TenMon.Checked == false && ckbTK_LoaiMon.Checked == false)
            {
                btn_TimKiemMenu.Enabled = false;
            }
            else
            {
                btn_TimKiemMenu.Enabled = true;
            }
        }

    }
}

