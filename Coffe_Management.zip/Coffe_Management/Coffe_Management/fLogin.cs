using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Coffe_Management
{
    public partial class fLogin : Form
    {
        public fLogin()
        {
            InitializeComponent();
        }
        Data data = new Data();
        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            if (txtTK.Text.Length > 0 && txtMK.Text.Length > 0)
            {
                string query = "SELECT MATKHAU FROM TAIKHOAN WHERE TAIKHOAN = @Value1";
                SqlParameter p = new SqlParameter("Value1", txtTK.Text);
                string cellValue = data.Scalar(query, p);
                if (!string.IsNullOrEmpty(cellValue))
                {
                    if (cellValue.Equals(txtMK.Text))
                    {
                        txtMK.Clear();
                        txtMK.Focus();
                        Coffee coffee = new Coffee(this, txtTK.Text);
                        coffee.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Sai mật khẩu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtMK.Clear();
                        txtMK.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Tài khoản không tồn tại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtTK.Text = "";
                    txtTK.Focus();
                }
            }
            else
            {
                if (txtTK.Text.Length == 0)
                {
                    MessageBox.Show("Chưa nhập tài khoản", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtTK.Focus();
                }else
                if (txtMK.Text.Length == 0)
                {
                    MessageBox.Show("Chưa nhập mật khẩu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtMK.Focus();
                }
            }
        }

        private void fLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
