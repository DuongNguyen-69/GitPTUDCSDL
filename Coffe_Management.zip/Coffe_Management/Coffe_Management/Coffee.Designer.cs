namespace Coffe_Management
{
    partial class Coffee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Coffee));
            this.error = new System.Windows.Forms.ErrorProvider(this.components);
            this.Order = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.cbox_Chuyenban = new System.Windows.Forms.ComboBox();
            this.btnChuyenban = new System.Windows.Forms.Button();
            this.grbox_Ban = new System.Windows.Forms.GroupBox();
            this.btn16 = new System.Windows.Forms.Button();
            this.btn15 = new System.Windows.Forms.Button();
            this.btn14 = new System.Windows.Forms.Button();
            this.btn13 = new System.Windows.Forms.Button();
            this.btn12 = new System.Windows.Forms.Button();
            this.btn11 = new System.Windows.Forms.Button();
            this.btn10 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cboxDouong = new System.Windows.Forms.ComboBox();
            this.btnThemMon = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.slOrder = new System.Windows.Forms.NumericUpDown();
            this.btnXoa = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.cboxDanhmucOrder = new System.Windows.Forms.ComboBox();
            this.btnDangXuat = new System.Windows.Forms.Button();
            this.QRCode = new System.Windows.Forms.Button();
            this.dgvOrder = new System.Windows.Forms.DataGridView();
            this.MAMON = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TENMON = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SOLUONG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.THANHTIEN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label9 = new System.Windows.Forms.Label();
            this.cboxDanhmucTenban = new System.Windows.Forms.ComboBox();
            this.btnThanhToan = new System.Windows.Forms.Button();
            this.txtThanhToan = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Menu = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_TimKiemMenu = new System.Windows.Forms.Button();
            this.ckbTK_DonGia = new System.Windows.Forms.CheckBox();
            this.ckbTK_LoaiMon = new System.Windows.Forms.CheckBox();
            this.ckbTK_TenMon = new System.Windows.Forms.CheckBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btn_ReLoad = new System.Windows.Forms.Button();
            this.btn_ThemMenu = new System.Windows.Forms.Button();
            this.btn_XoaMenu = new System.Windows.Forms.Button();
            this.btn_SuaMenu = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dtvgMenu = new System.Windows.Forms.DataGridView();
            this.MaMonMenu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenMonMenu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenLoaiMonMenu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaMenu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.txt_DonGia = new System.Windows.Forms.TextBox();
            this.cb_LoaiMon = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.txt_TenMon = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txt_MaMon = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.LoaiMon = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.dgvLoaiMon = new System.Windows.Forms.DataGridView();
            this.MALOAI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TENLOAI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnReloadLoaiMon = new System.Windows.Forms.Button();
            this.btnTimKiemLoaiMon = new System.Windows.Forms.Button();
            this.txtTenLoaiMon = new System.Windows.Forms.TextBox();
            this.btnXoaLoaiMon = new System.Windows.Forms.Button();
            this.btnSuaLoaiMon = new System.Windows.Forms.Button();
            this.txtMaLoaiMon = new System.Windows.Forms.TextBox();
            this.btnThemLoaiMon = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.btnDoiMK_tabTK = new System.Windows.Forms.Button();
            this.btnXoaTK_tabTK = new System.Windows.Forms.Button();
            this.btnSuaThongTin_TabTK = new System.Windows.Forms.Button();
            this.cmbChucVu_tabTaiKhoan = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtTenHienThi_tabTaiKhoan = new System.Windows.Forms.TextBox();
            this.btnTaoTK_tabTK = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.txtTaiKhoan_tabTaiKhoan = new System.Windows.Forms.TextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.dgvTK = new System.Windows.Forms.DataGridView();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.printDoc_Hoadon = new System.Drawing.Printing.PrintDocument();
            this.printPreview_Hoadon = new System.Windows.Forms.PrintPreviewDialog();
            ((System.ComponentModel.ISupportInitialize)(this.error)).BeginInit();
            this.Order.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.grbox_Ban.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.slOrder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrder)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.Menu.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtvgMenu)).BeginInit();
            this.groupBox14.SuspendLayout();
            this.panel3.SuspendLayout();
            this.LoaiMon.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLoaiMon)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTK)).BeginInit();
            this.SuspendLayout();
            // 
            // error
            // 
            this.error.ContainerControl = this;
            // 
            // Order
            // 
            this.Order.BackColor = System.Drawing.Color.SkyBlue;
            this.Order.Controls.Add(this.groupBox8);
            this.Order.Controls.Add(this.grbox_Ban);
            this.Order.Controls.Add(this.groupBox9);
            this.Order.Controls.Add(this.btnDangXuat);
            this.Order.Controls.Add(this.QRCode);
            this.Order.Controls.Add(this.dgvOrder);
            this.Order.Controls.Add(this.label9);
            this.Order.Controls.Add(this.cboxDanhmucTenban);
            this.Order.Controls.Add(this.btnThanhToan);
            this.Order.Controls.Add(this.txtThanhToan);
            this.Order.Controls.Add(this.label4);
            this.Order.Location = new System.Drawing.Point(4, 44);
            this.Order.Margin = new System.Windows.Forms.Padding(7);
            this.Order.Name = "Order";
            this.Order.Padding = new System.Windows.Forms.Padding(7);
            this.Order.Size = new System.Drawing.Size(1267, 661);
            this.Order.TabIndex = 0;
            this.Order.Text = "Order";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.cbox_Chuyenban);
            this.groupBox8.Controls.Add(this.btnChuyenban);
            this.groupBox8.Location = new System.Drawing.Point(45, 538);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(396, 102);
            this.groupBox8.TabIndex = 44;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Chuyển bàn";
            // 
            // cbox_Chuyenban
            // 
            this.cbox_Chuyenban.FormattingEnabled = true;
            this.cbox_Chuyenban.Location = new System.Drawing.Point(25, 44);
            this.cbox_Chuyenban.Margin = new System.Windows.Forms.Padding(2);
            this.cbox_Chuyenban.Name = "cbox_Chuyenban";
            this.cbox_Chuyenban.Size = new System.Drawing.Size(162, 27);
            this.cbox_Chuyenban.TabIndex = 41;
            // 
            // btnChuyenban
            // 
            this.btnChuyenban.Location = new System.Drawing.Point(226, 38);
            this.btnChuyenban.Name = "btnChuyenban";
            this.btnChuyenban.Size = new System.Drawing.Size(148, 36);
            this.btnChuyenban.TabIndex = 42;
            this.btnChuyenban.Text = "Chuyển bàn";
            this.btnChuyenban.UseVisualStyleBackColor = true;
            this.btnChuyenban.Click += new System.EventHandler(this.btnChuyenban_Click);
            // 
            // grbox_Ban
            // 
            this.grbox_Ban.Controls.Add(this.btn16);
            this.grbox_Ban.Controls.Add(this.btn15);
            this.grbox_Ban.Controls.Add(this.btn14);
            this.grbox_Ban.Controls.Add(this.btn13);
            this.grbox_Ban.Controls.Add(this.btn12);
            this.grbox_Ban.Controls.Add(this.btn11);
            this.grbox_Ban.Controls.Add(this.btn10);
            this.grbox_Ban.Controls.Add(this.btn9);
            this.grbox_Ban.Controls.Add(this.btn1);
            this.grbox_Ban.Controls.Add(this.btn8);
            this.grbox_Ban.Controls.Add(this.btn2);
            this.grbox_Ban.Controls.Add(this.btn7);
            this.grbox_Ban.Controls.Add(this.btn3);
            this.grbox_Ban.Controls.Add(this.btn6);
            this.grbox_Ban.Controls.Add(this.btn4);
            this.grbox_Ban.Controls.Add(this.btn5);
            this.grbox_Ban.Location = new System.Drawing.Point(10, 37);
            this.grbox_Ban.Name = "grbox_Ban";
            this.grbox_Ban.Size = new System.Drawing.Size(503, 478);
            this.grbox_Ban.TabIndex = 43;
            this.grbox_Ban.TabStop = false;
            this.grbox_Ban.Text = "Sơ đồ bàn";
            // 
            // btn16
            // 
            this.btn16.BackColor = System.Drawing.Color.White;
            this.btn16.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn16.Location = new System.Drawing.Point(380, 383);
            this.btn16.Margin = new System.Windows.Forms.Padding(2);
            this.btn16.Name = "btn16";
            this.btn16.Size = new System.Drawing.Size(81, 81);
            this.btn16.TabIndex = 43;
            this.btn16.Text = "Bàn 16";
            this.btn16.UseVisualStyleBackColor = false;
            this.btn16.Click += new System.EventHandler(this.btn16_Click);
            // 
            // btn15
            // 
            this.btn15.BackColor = System.Drawing.Color.White;
            this.btn15.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn15.Location = new System.Drawing.Point(264, 383);
            this.btn15.Margin = new System.Windows.Forms.Padding(2);
            this.btn15.Name = "btn15";
            this.btn15.Size = new System.Drawing.Size(81, 81);
            this.btn15.TabIndex = 42;
            this.btn15.Text = "Bàn 15";
            this.btn15.UseVisualStyleBackColor = false;
            this.btn15.Click += new System.EventHandler(this.btn15_Click);
            // 
            // btn14
            // 
            this.btn14.BackColor = System.Drawing.Color.White;
            this.btn14.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn14.Location = new System.Drawing.Point(150, 383);
            this.btn14.Margin = new System.Windows.Forms.Padding(2);
            this.btn14.Name = "btn14";
            this.btn14.Size = new System.Drawing.Size(81, 81);
            this.btn14.TabIndex = 41;
            this.btn14.Text = "Bàn 14";
            this.btn14.UseVisualStyleBackColor = false;
            this.btn14.Click += new System.EventHandler(this.btn14_Click);
            // 
            // btn13
            // 
            this.btn13.BackColor = System.Drawing.Color.White;
            this.btn13.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn13.Location = new System.Drawing.Point(35, 383);
            this.btn13.Margin = new System.Windows.Forms.Padding(2);
            this.btn13.Name = "btn13";
            this.btn13.Size = new System.Drawing.Size(81, 81);
            this.btn13.TabIndex = 40;
            this.btn13.Text = "Bàn 13";
            this.btn13.UseVisualStyleBackColor = false;
            this.btn13.Click += new System.EventHandler(this.btn13_Click);
            // 
            // btn12
            // 
            this.btn12.BackColor = System.Drawing.Color.White;
            this.btn12.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn12.Location = new System.Drawing.Point(380, 274);
            this.btn12.Margin = new System.Windows.Forms.Padding(2);
            this.btn12.Name = "btn12";
            this.btn12.Size = new System.Drawing.Size(81, 81);
            this.btn12.TabIndex = 39;
            this.btn12.Text = "Bàn 12";
            this.btn12.UseVisualStyleBackColor = false;
            this.btn12.Click += new System.EventHandler(this.btn12_Click);
            // 
            // btn11
            // 
            this.btn11.BackColor = System.Drawing.Color.White;
            this.btn11.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn11.Location = new System.Drawing.Point(264, 274);
            this.btn11.Margin = new System.Windows.Forms.Padding(2);
            this.btn11.Name = "btn11";
            this.btn11.Size = new System.Drawing.Size(81, 81);
            this.btn11.TabIndex = 38;
            this.btn11.Text = "Bàn 11";
            this.btn11.UseVisualStyleBackColor = false;
            this.btn11.Click += new System.EventHandler(this.btn11_Click);
            // 
            // btn10
            // 
            this.btn10.BackColor = System.Drawing.Color.White;
            this.btn10.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn10.Location = new System.Drawing.Point(150, 274);
            this.btn10.Margin = new System.Windows.Forms.Padding(2);
            this.btn10.Name = "btn10";
            this.btn10.Size = new System.Drawing.Size(81, 81);
            this.btn10.TabIndex = 37;
            this.btn10.Text = "Bàn 10";
            this.btn10.UseVisualStyleBackColor = false;
            this.btn10.Click += new System.EventHandler(this.btn10_Click);
            // 
            // btn9
            // 
            this.btn9.BackColor = System.Drawing.Color.White;
            this.btn9.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn9.Location = new System.Drawing.Point(35, 274);
            this.btn9.Margin = new System.Windows.Forms.Padding(2);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(81, 81);
            this.btn9.TabIndex = 36;
            this.btn9.Text = "Bàn 9";
            this.btn9.UseVisualStyleBackColor = false;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.Color.White;
            this.btn1.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1.Location = new System.Drawing.Point(35, 50);
            this.btn1.Margin = new System.Windows.Forms.Padding(2);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(81, 81);
            this.btn1.TabIndex = 28;
            this.btn1.Text = "Bàn 1";
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btn8
            // 
            this.btn8.BackColor = System.Drawing.Color.White;
            this.btn8.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn8.Location = new System.Drawing.Point(380, 160);
            this.btn8.Margin = new System.Windows.Forms.Padding(2);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(81, 81);
            this.btn8.TabIndex = 35;
            this.btn8.Text = "Bàn 8";
            this.btn8.UseVisualStyleBackColor = false;
            this.btn8.Click += new System.EventHandler(this.btn8_Click);
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.Color.White;
            this.btn2.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn2.Location = new System.Drawing.Point(150, 50);
            this.btn2.Margin = new System.Windows.Forms.Padding(2);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(81, 81);
            this.btn2.TabIndex = 29;
            this.btn2.Text = "Bàn 2";
            this.btn2.UseVisualStyleBackColor = false;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btn7
            // 
            this.btn7.BackColor = System.Drawing.Color.White;
            this.btn7.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn7.Location = new System.Drawing.Point(264, 160);
            this.btn7.Margin = new System.Windows.Forms.Padding(2);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(81, 81);
            this.btn7.TabIndex = 34;
            this.btn7.Text = "Bàn 7";
            this.btn7.UseVisualStyleBackColor = false;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // btn3
            // 
            this.btn3.BackColor = System.Drawing.Color.White;
            this.btn3.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn3.Location = new System.Drawing.Point(264, 50);
            this.btn3.Margin = new System.Windows.Forms.Padding(2);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(81, 81);
            this.btn3.TabIndex = 30;
            this.btn3.Text = "Bàn 3";
            this.btn3.UseVisualStyleBackColor = false;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn6
            // 
            this.btn6.BackColor = System.Drawing.Color.White;
            this.btn6.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn6.Location = new System.Drawing.Point(150, 160);
            this.btn6.Margin = new System.Windows.Forms.Padding(2);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(81, 81);
            this.btn6.TabIndex = 33;
            this.btn6.Text = "Bàn 6";
            this.btn6.UseVisualStyleBackColor = false;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // btn4
            // 
            this.btn4.BackColor = System.Drawing.Color.White;
            this.btn4.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn4.Location = new System.Drawing.Point(380, 50);
            this.btn4.Margin = new System.Windows.Forms.Padding(2);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(81, 81);
            this.btn4.TabIndex = 31;
            this.btn4.Text = "Bàn 4";
            this.btn4.UseVisualStyleBackColor = false;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btn5
            // 
            this.btn5.BackColor = System.Drawing.Color.White;
            this.btn5.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn5.Location = new System.Drawing.Point(35, 160);
            this.btn5.Margin = new System.Windows.Forms.Padding(2);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(81, 81);
            this.btn5.TabIndex = 32;
            this.btn5.Text = "Bàn 5";
            this.btn5.UseVisualStyleBackColor = false;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label1);
            this.groupBox9.Controls.Add(this.cboxDouong);
            this.groupBox9.Controls.Add(this.btnThemMon);
            this.groupBox9.Controls.Add(this.label2);
            this.groupBox9.Controls.Add(this.slOrder);
            this.groupBox9.Controls.Add(this.btnXoa);
            this.groupBox9.Controls.Add(this.label3);
            this.groupBox9.Controls.Add(this.cboxDanhmucOrder);
            this.groupBox9.Location = new System.Drawing.Point(541, 37);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(582, 131);
            this.groupBox9.TabIndex = 33;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Chọn thực đơn";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(19, 30);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Danh mục:";
            // 
            // cboxDouong
            // 
            this.cboxDouong.FormattingEnabled = true;
            this.cboxDouong.Location = new System.Drawing.Point(132, 62);
            this.cboxDouong.Margin = new System.Windows.Forms.Padding(2);
            this.cboxDouong.Name = "cboxDouong";
            this.cboxDouong.Size = new System.Drawing.Size(267, 27);
            this.cboxDouong.TabIndex = 3;
            // 
            // btnThemMon
            // 
            this.btnThemMon.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThemMon.Location = new System.Drawing.Point(439, 30);
            this.btnThemMon.Margin = new System.Windows.Forms.Padding(2);
            this.btnThemMon.Name = "btnThemMon";
            this.btnThemMon.Size = new System.Drawing.Size(101, 43);
            this.btnThemMon.TabIndex = 6;
            this.btnThemMon.Text = "Thêm món";
            this.btnThemMon.UseVisualStyleBackColor = true;
            this.btnThemMon.Click += new System.EventHandler(this.btnThemMon_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(19, 62);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tên món:";
            // 
            // slOrder
            // 
            this.slOrder.BackColor = System.Drawing.SystemColors.Window;
            this.slOrder.ForeColor = System.Drawing.SystemColors.WindowText;
            this.slOrder.Location = new System.Drawing.Point(132, 94);
            this.slOrder.Margin = new System.Windows.Forms.Padding(2);
            this.slOrder.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.slOrder.Name = "slOrder";
            this.slOrder.Size = new System.Drawing.Size(61, 27);
            this.slOrder.TabIndex = 5;
            this.slOrder.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btnXoa
            // 
            this.btnXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa.Location = new System.Drawing.Point(439, 78);
            this.btnXoa.Margin = new System.Windows.Forms.Padding(2);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(101, 43);
            this.btnXoa.TabIndex = 32;
            this.btnXoa.Text = "Xóa món";
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(19, 96);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 19);
            this.label3.TabIndex = 4;
            this.label3.Text = "Số lượng";
            // 
            // cboxDanhmucOrder
            // 
            this.cboxDanhmucOrder.FormattingEnabled = true;
            this.cboxDanhmucOrder.Location = new System.Drawing.Point(132, 27);
            this.cboxDanhmucOrder.Margin = new System.Windows.Forms.Padding(2);
            this.cboxDanhmucOrder.Name = "cboxDanhmucOrder";
            this.cboxDanhmucOrder.Size = new System.Drawing.Size(267, 27);
            this.cboxDanhmucOrder.TabIndex = 2;
            this.cboxDanhmucOrder.SelectedIndexChanged += new System.EventHandler(this.cboxDanhmucOrder_SelectedIndexChanged);
            // 
            // btnDangXuat
            // 
            this.btnDangXuat.Location = new System.Drawing.Point(1142, 83);
            this.btnDangXuat.Name = "btnDangXuat";
            this.btnDangXuat.Size = new System.Drawing.Size(92, 43);
            this.btnDangXuat.TabIndex = 37;
            this.btnDangXuat.Text = "Đăng xuất";
            this.btnDangXuat.UseVisualStyleBackColor = true;
            this.btnDangXuat.Click += new System.EventHandler(this.btnDangXuat_Click);
            // 
            // QRCode
            // 
            this.QRCode.BackgroundImage = global::Coffe_Management.Properties.Resources.cach_quet_ma_qr_hinh_1;
            this.QRCode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.QRCode.Location = new System.Drawing.Point(930, 590);
            this.QRCode.Margin = new System.Windows.Forms.Padding(2);
            this.QRCode.Name = "QRCode";
            this.QRCode.Size = new System.Drawing.Size(65, 59);
            this.QRCode.TabIndex = 33;
            this.QRCode.UseVisualStyleBackColor = true;
            this.QRCode.Click += new System.EventHandler(this.QRCode_Click);
            // 
            // dgvOrder
            // 
            this.dgvOrder.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOrder.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MAMON,
            this.TENMON,
            this.SOLUONG,
            this.THANHTIEN});
            this.dgvOrder.Location = new System.Drawing.Point(541, 173);
            this.dgvOrder.Margin = new System.Windows.Forms.Padding(2);
            this.dgvOrder.MultiSelect = false;
            this.dgvOrder.Name = "dgvOrder";
            this.dgvOrder.ReadOnly = true;
            this.dgvOrder.RowHeadersVisible = false;
            this.dgvOrder.RowHeadersWidth = 51;
            this.dgvOrder.Size = new System.Drawing.Size(702, 342);
            this.dgvOrder.TabIndex = 31;
            // 
            // MAMON
            // 
            this.MAMON.DataPropertyName = "MAMON";
            this.MAMON.HeaderText = "Mã món";
            this.MAMON.MinimumWidth = 6;
            this.MAMON.Name = "MAMON";
            this.MAMON.ReadOnly = true;
            this.MAMON.Visible = false;
            this.MAMON.Width = 125;
            // 
            // TENMON
            // 
            this.TENMON.DataPropertyName = "TENMON";
            this.TENMON.HeaderText = "Tên món";
            this.TENMON.MinimumWidth = 6;
            this.TENMON.Name = "TENMON";
            this.TENMON.ReadOnly = true;
            this.TENMON.Width = 270;
            // 
            // SOLUONG
            // 
            this.SOLUONG.DataPropertyName = "SOLUONG";
            this.SOLUONG.HeaderText = "Số lượng";
            this.SOLUONG.MinimumWidth = 6;
            this.SOLUONG.Name = "SOLUONG";
            this.SOLUONG.ReadOnly = true;
            this.SOLUONG.Width = 125;
            // 
            // THANHTIEN
            // 
            this.THANHTIEN.DataPropertyName = "THANHTIEN";
            this.THANHTIEN.HeaderText = "Thành tiền";
            this.THANHTIEN.MinimumWidth = 6;
            this.THANHTIEN.Name = "THANHTIEN";
            this.THANHTIEN.ReadOnly = true;
            this.THANHTIEN.Width = 300;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(614, 541);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(38, 19);
            this.label9.TabIndex = 30;
            this.label9.Text = "Bàn";
            // 
            // cboxDanhmucTenban
            // 
            this.cboxDanhmucTenban.FormattingEnabled = true;
            this.cboxDanhmucTenban.Location = new System.Drawing.Point(666, 538);
            this.cboxDanhmucTenban.Margin = new System.Windows.Forms.Padding(2);
            this.cboxDanhmucTenban.Name = "cboxDanhmucTenban";
            this.cboxDanhmucTenban.Size = new System.Drawing.Size(105, 27);
            this.cboxDanhmucTenban.TabIndex = 28;
            this.cboxDanhmucTenban.SelectedIndexChanged += new System.EventHandler(this.cboxDanhmucTenban_SelectedIndexChanged);
            // 
            // btnThanhToan
            // 
            this.btnThanhToan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThanhToan.Location = new System.Drawing.Point(1011, 597);
            this.btnThanhToan.Margin = new System.Windows.Forms.Padding(2);
            this.btnThanhToan.Name = "btnThanhToan";
            this.btnThanhToan.Size = new System.Drawing.Size(146, 43);
            this.btnThanhToan.TabIndex = 8;
            this.btnThanhToan.Text = "Thanh toán";
            this.btnThanhToan.UseVisualStyleBackColor = true;
            this.btnThanhToan.Click += new System.EventHandler(this.btnThanhToan_Click);
            // 
            // txtThanhToan
            // 
            this.txtThanhToan.Enabled = false;
            this.txtThanhToan.Location = new System.Drawing.Point(872, 538);
            this.txtThanhToan.Margin = new System.Windows.Forms.Padding(2);
            this.txtThanhToan.Name = "txtThanhToan";
            this.txtThanhToan.Size = new System.Drawing.Size(355, 27);
            this.txtThanhToan.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(789, 544);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 19);
            this.label4.TabIndex = 11;
            this.label4.Text = "Tổng tiền";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Order);
            this.tabControl1.Controls.Add(this.Menu);
            this.tabControl1.Controls.Add(this.LoaiMon);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.ItemSize = new System.Drawing.Size(49, 40);
            this.tabControl1.Location = new System.Drawing.Point(-4, -1);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(7);
            this.tabControl1.MinimumSize = new System.Drawing.Size(1249, 674);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1275, 709);
            this.tabControl1.TabIndex = 33;
            // 
            // Menu
            // 
            this.Menu.BackColor = System.Drawing.Color.LightSalmon;
            this.Menu.Controls.Add(this.groupBox1);
            this.Menu.Controls.Add(this.groupBox6);
            this.Menu.Controls.Add(this.groupBox4);
            this.Menu.Controls.Add(this.groupBox14);
            this.Menu.Controls.Add(this.panel3);
            this.Menu.Location = new System.Drawing.Point(4, 44);
            this.Menu.Name = "Menu";
            this.Menu.Size = new System.Drawing.Size(1267, 661);
            this.Menu.TabIndex = 7;
            this.Menu.Text = "Menu";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_TimKiemMenu);
            this.groupBox1.Controls.Add(this.ckbTK_DonGia);
            this.groupBox1.Controls.Add(this.ckbTK_LoaiMon);
            this.groupBox1.Controls.Add(this.ckbTK_TenMon);
            this.groupBox1.Location = new System.Drawing.Point(706, 445);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(508, 100);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tìm kiếm";
            // 
            // btn_TimKiemMenu
            // 
            this.btn_TimKiemMenu.Location = new System.Drawing.Point(349, 31);
            this.btn_TimKiemMenu.Name = "btn_TimKiemMenu";
            this.btn_TimKiemMenu.Size = new System.Drawing.Size(117, 54);
            this.btn_TimKiemMenu.TabIndex = 3;
            this.btn_TimKiemMenu.Text = "Tìm kiếm";
            this.btn_TimKiemMenu.UseVisualStyleBackColor = true;
            this.btn_TimKiemMenu.Click += new System.EventHandler(this.btn_TimKiemMenu_Click);
            // 
            // ckbTK_DonGia
            // 
            this.ckbTK_DonGia.AutoSize = true;
            this.ckbTK_DonGia.Location = new System.Drawing.Point(171, 31);
            this.ckbTK_DonGia.Name = "ckbTK_DonGia";
            this.ckbTK_DonGia.Size = new System.Drawing.Size(81, 23);
            this.ckbTK_DonGia.TabIndex = 2;
            this.ckbTK_DonGia.Text = "Đơn giá";
            this.ckbTK_DonGia.UseVisualStyleBackColor = true;
            this.ckbTK_DonGia.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // ckbTK_LoaiMon
            // 
            this.ckbTK_LoaiMon.AutoSize = true;
            this.ckbTK_LoaiMon.Location = new System.Drawing.Point(16, 60);
            this.ckbTK_LoaiMon.Name = "ckbTK_LoaiMon";
            this.ckbTK_LoaiMon.Size = new System.Drawing.Size(93, 23);
            this.ckbTK_LoaiMon.TabIndex = 1;
            this.ckbTK_LoaiMon.Text = "Loại món";
            this.ckbTK_LoaiMon.UseVisualStyleBackColor = true;
            this.ckbTK_LoaiMon.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // ckbTK_TenMon
            // 
            this.ckbTK_TenMon.AutoSize = true;
            this.ckbTK_TenMon.Location = new System.Drawing.Point(16, 31);
            this.ckbTK_TenMon.Name = "ckbTK_TenMon";
            this.ckbTK_TenMon.Size = new System.Drawing.Size(87, 23);
            this.ckbTK_TenMon.TabIndex = 0;
            this.ckbTK_TenMon.Text = "Tên món";
            this.ckbTK_TenMon.UseVisualStyleBackColor = true;
            this.ckbTK_TenMon.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btn_ReLoad);
            this.groupBox6.Controls.Add(this.btn_ThemMenu);
            this.groupBox6.Controls.Add(this.btn_XoaMenu);
            this.groupBox6.Controls.Add(this.btn_SuaMenu);
            this.groupBox6.Location = new System.Drawing.Point(706, 285);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(508, 125);
            this.groupBox6.TabIndex = 20;
            this.groupBox6.TabStop = false;
            // 
            // btn_ReLoad
            // 
            this.btn_ReLoad.Location = new System.Drawing.Point(387, 45);
            this.btn_ReLoad.Name = "btn_ReLoad";
            this.btn_ReLoad.Size = new System.Drawing.Size(115, 54);
            this.btn_ReLoad.TabIndex = 3;
            this.btn_ReLoad.Text = "ReLoad";
            this.btn_ReLoad.UseVisualStyleBackColor = true;
            this.btn_ReLoad.Click += new System.EventHandler(this.btn_ReLoad_Click);
            // 
            // btn_ThemMenu
            // 
            this.btn_ThemMenu.Location = new System.Drawing.Point(6, 45);
            this.btn_ThemMenu.Name = "btn_ThemMenu";
            this.btn_ThemMenu.Size = new System.Drawing.Size(115, 54);
            this.btn_ThemMenu.TabIndex = 0;
            this.btn_ThemMenu.Text = "Thêm";
            this.btn_ThemMenu.UseVisualStyleBackColor = true;
            this.btn_ThemMenu.Click += new System.EventHandler(this.btn_ThemMenu_Click);
            // 
            // btn_XoaMenu
            // 
            this.btn_XoaMenu.Location = new System.Drawing.Point(260, 45);
            this.btn_XoaMenu.Name = "btn_XoaMenu";
            this.btn_XoaMenu.Size = new System.Drawing.Size(115, 54);
            this.btn_XoaMenu.TabIndex = 2;
            this.btn_XoaMenu.Text = "Xoá";
            this.btn_XoaMenu.UseVisualStyleBackColor = true;
            this.btn_XoaMenu.Click += new System.EventHandler(this.btn_XoaMenu_Click);
            // 
            // btn_SuaMenu
            // 
            this.btn_SuaMenu.Location = new System.Drawing.Point(133, 45);
            this.btn_SuaMenu.Name = "btn_SuaMenu";
            this.btn_SuaMenu.Size = new System.Drawing.Size(115, 54);
            this.btn_SuaMenu.TabIndex = 1;
            this.btn_SuaMenu.Text = "Sửa";
            this.btn_SuaMenu.UseVisualStyleBackColor = true;
            this.btn_SuaMenu.Click += new System.EventHandler(this.btn_SuaMenu_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dtvgMenu);
            this.groupBox4.Location = new System.Drawing.Point(12, 16);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(665, 620);
            this.groupBox4.TabIndex = 19;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Quản Lý Menu";
            // 
            // dtvgMenu
            // 
            this.dtvgMenu.AllowUserToAddRows = false;
            this.dtvgMenu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtvgMenu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaMonMenu,
            this.TenMonMenu,
            this.TenLoaiMonMenu,
            this.GiaMenu});
            this.dtvgMenu.Location = new System.Drawing.Point(6, 37);
            this.dtvgMenu.MultiSelect = false;
            this.dtvgMenu.Name = "dtvgMenu";
            this.dtvgMenu.ReadOnly = true;
            this.dtvgMenu.RowHeadersVisible = false;
            this.dtvgMenu.RowHeadersWidth = 51;
            this.dtvgMenu.Size = new System.Drawing.Size(630, 566);
            this.dtvgMenu.TabIndex = 2;
            this.dtvgMenu.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtvgMenu_CellClick);
            // 
            // MaMonMenu
            // 
            this.MaMonMenu.DataPropertyName = "MAMON";
            this.MaMonMenu.HeaderText = "Mã món";
            this.MaMonMenu.MinimumWidth = 6;
            this.MaMonMenu.Name = "MaMonMenu";
            this.MaMonMenu.ReadOnly = true;
            this.MaMonMenu.Width = 130;
            // 
            // TenMonMenu
            // 
            this.TenMonMenu.DataPropertyName = "TENMON";
            this.TenMonMenu.HeaderText = "Tên món";
            this.TenMonMenu.MinimumWidth = 6;
            this.TenMonMenu.Name = "TenMonMenu";
            this.TenMonMenu.ReadOnly = true;
            this.TenMonMenu.Width = 200;
            // 
            // TenLoaiMonMenu
            // 
            this.TenLoaiMonMenu.DataPropertyName = "TENLOAI";
            this.TenLoaiMonMenu.HeaderText = "Tên loại món";
            this.TenLoaiMonMenu.MinimumWidth = 6;
            this.TenLoaiMonMenu.Name = "TenLoaiMonMenu";
            this.TenLoaiMonMenu.ReadOnly = true;
            this.TenLoaiMonMenu.Width = 170;
            // 
            // GiaMenu
            // 
            this.GiaMenu.DataPropertyName = "GIA";
            this.GiaMenu.HeaderText = "Giá";
            this.GiaMenu.MinimumWidth = 6;
            this.GiaMenu.Name = "GiaMenu";
            this.GiaMenu.ReadOnly = true;
            this.GiaMenu.Width = 125;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.txt_DonGia);
            this.groupBox14.Controls.Add(this.cb_LoaiMon);
            this.groupBox14.Controls.Add(this.label28);
            this.groupBox14.Controls.Add(this.label31);
            this.groupBox14.Controls.Add(this.label32);
            this.groupBox14.Controls.Add(this.txt_TenMon);
            this.groupBox14.Controls.Add(this.label33);
            this.groupBox14.Controls.Add(this.txt_MaMon);
            this.groupBox14.Location = new System.Drawing.Point(706, 16);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(508, 244);
            this.groupBox14.TabIndex = 4;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Thông tin Menu";
            // 
            // txt_DonGia
            // 
            this.txt_DonGia.Location = new System.Drawing.Point(110, 181);
            this.txt_DonGia.Name = "txt_DonGia";
            this.txt_DonGia.Size = new System.Drawing.Size(188, 27);
            this.txt_DonGia.TabIndex = 17;
            this.txt_DonGia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_DonGia_KeyPress);
            // 
            // cb_LoaiMon
            // 
            this.cb_LoaiMon.FormattingEnabled = true;
            this.cb_LoaiMon.Location = new System.Drawing.Point(110, 128);
            this.cb_LoaiMon.Name = "cb_LoaiMon";
            this.cb_LoaiMon.Size = new System.Drawing.Size(188, 27);
            this.cb_LoaiMon.TabIndex = 15;
            this.cb_LoaiMon.SelectedValueChanged += new System.EventHandler(this.cb_LoaiMon_SelectedValueChanged);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(20, 131);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(74, 19);
            this.label28.TabIndex = 13;
            this.label28.Text = "Loại món";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(22, 185);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(62, 19);
            this.label31.TabIndex = 7;
            this.label31.Text = "Đơn giá";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(20, 77);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(68, 19);
            this.label32.TabIndex = 5;
            this.label32.Text = "Tên món";
            // 
            // txt_TenMon
            // 
            this.txt_TenMon.Location = new System.Drawing.Point(110, 74);
            this.txt_TenMon.Name = "txt_TenMon";
            this.txt_TenMon.Size = new System.Drawing.Size(392, 27);
            this.txt_TenMon.TabIndex = 4;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(20, 23);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(65, 19);
            this.label33.TabIndex = 3;
            this.label33.Text = "Mã món";
            // 
            // txt_MaMon
            // 
            this.txt_MaMon.Location = new System.Drawing.Point(110, 20);
            this.txt_MaMon.Name = "txt_MaMon";
            this.txt_MaMon.ReadOnly = true;
            this.txt_MaMon.Size = new System.Drawing.Size(392, 27);
            this.txt_MaMon.TabIndex = 2;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button8);
            this.panel3.Controls.Add(this.button9);
            this.panel3.Controls.Add(this.button10);
            this.panel3.Controls.Add(this.button7);
            this.panel3.Location = new System.Drawing.Point(1442, 477);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(508, 83);
            this.panel3.TabIndex = 3;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(376, 14);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(117, 54);
            this.button8.TabIndex = 3;
            this.button8.Text = "Tìm kiếm";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(256, 14);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(114, 54);
            this.button9.TabIndex = 2;
            this.button9.Text = "Xoá";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(133, 14);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(117, 54);
            this.button10.TabIndex = 1;
            this.button10.Text = "Sửa";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(16, 14);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(114, 54);
            this.button7.TabIndex = 0;
            this.button7.Text = "Thêm";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // LoaiMon
            // 
            this.LoaiMon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.LoaiMon.Controls.Add(this.groupBox5);
            this.LoaiMon.Controls.Add(this.groupBox3);
            this.LoaiMon.Location = new System.Drawing.Point(4, 44);
            this.LoaiMon.Name = "LoaiMon";
            this.LoaiMon.Padding = new System.Windows.Forms.Padding(3);
            this.LoaiMon.Size = new System.Drawing.Size(1267, 661);
            this.LoaiMon.TabIndex = 8;
            this.LoaiMon.Text = "Loại Món";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.dgvLoaiMon);
            this.groupBox5.Location = new System.Drawing.Point(20, 22);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(595, 614);
            this.groupBox5.TabIndex = 8;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Quản Lý Loại Món";
            // 
            // dgvLoaiMon
            // 
            this.dgvLoaiMon.AllowUserToAddRows = false;
            this.dgvLoaiMon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLoaiMon.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MALOAI,
            this.TENLOAI});
            this.dgvLoaiMon.Location = new System.Drawing.Point(17, 26);
            this.dgvLoaiMon.MultiSelect = false;
            this.dgvLoaiMon.Name = "dgvLoaiMon";
            this.dgvLoaiMon.ReadOnly = true;
            this.dgvLoaiMon.RowHeadersVisible = false;
            this.dgvLoaiMon.RowHeadersWidth = 51;
            this.dgvLoaiMon.Size = new System.Drawing.Size(553, 568);
            this.dgvLoaiMon.TabIndex = 7;
            this.dgvLoaiMon.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvLoaiMon_CellClick);
            // 
            // MALOAI
            // 
            this.MALOAI.DataPropertyName = "MALOAI";
            this.MALOAI.HeaderText = "Mã Loại";
            this.MALOAI.MinimumWidth = 6;
            this.MALOAI.Name = "MALOAI";
            this.MALOAI.ReadOnly = true;
            this.MALOAI.Width = 220;
            // 
            // TENLOAI
            // 
            this.TENLOAI.DataPropertyName = "TENLOAI";
            this.TENLOAI.HeaderText = "Tên Loại";
            this.TENLOAI.MinimumWidth = 6;
            this.TENLOAI.Name = "TENLOAI";
            this.TENLOAI.ReadOnly = true;
            this.TENLOAI.Width = 330;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnReloadLoaiMon);
            this.groupBox3.Controls.Add(this.btnTimKiemLoaiMon);
            this.groupBox3.Controls.Add(this.txtTenLoaiMon);
            this.groupBox3.Controls.Add(this.btnXoaLoaiMon);
            this.groupBox3.Controls.Add(this.btnSuaLoaiMon);
            this.groupBox3.Controls.Add(this.txtMaLoaiMon);
            this.groupBox3.Controls.Add(this.btnThemLoaiMon);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Location = new System.Drawing.Point(640, 166);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(604, 370);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Thông tin loại món";
            // 
            // btnReloadLoaiMon
            // 
            this.btnReloadLoaiMon.Location = new System.Drawing.Point(487, 219);
            this.btnReloadLoaiMon.Name = "btnReloadLoaiMon";
            this.btnReloadLoaiMon.Size = new System.Drawing.Size(91, 44);
            this.btnReloadLoaiMon.TabIndex = 14;
            this.btnReloadLoaiMon.Text = "Reload";
            this.btnReloadLoaiMon.UseVisualStyleBackColor = true;
            this.btnReloadLoaiMon.Click += new System.EventHandler(this.btnReloadLoaiMon_Click);
            // 
            // btnTimKiemLoaiMon
            // 
            this.btnTimKiemLoaiMon.Location = new System.Drawing.Point(373, 219);
            this.btnTimKiemLoaiMon.Name = "btnTimKiemLoaiMon";
            this.btnTimKiemLoaiMon.Size = new System.Drawing.Size(95, 44);
            this.btnTimKiemLoaiMon.TabIndex = 13;
            this.btnTimKiemLoaiMon.Text = "Tìm Kiếm";
            this.btnTimKiemLoaiMon.UseVisualStyleBackColor = true;
            this.btnTimKiemLoaiMon.Click += new System.EventHandler(this.btnTimKiemLoaiMon_Click);
            // 
            // txtTenLoaiMon
            // 
            this.txtTenLoaiMon.Location = new System.Drawing.Point(201, 142);
            this.txtTenLoaiMon.Name = "txtTenLoaiMon";
            this.txtTenLoaiMon.Size = new System.Drawing.Size(346, 27);
            this.txtTenLoaiMon.TabIndex = 12;
            // 
            // btnXoaLoaiMon
            // 
            this.btnXoaLoaiMon.Location = new System.Drawing.Point(258, 219);
            this.btnXoaLoaiMon.Name = "btnXoaLoaiMon";
            this.btnXoaLoaiMon.Size = new System.Drawing.Size(95, 44);
            this.btnXoaLoaiMon.TabIndex = 8;
            this.btnXoaLoaiMon.Text = "Xoá";
            this.btnXoaLoaiMon.UseVisualStyleBackColor = true;
            this.btnXoaLoaiMon.Click += new System.EventHandler(this.btnXoaLoaiMon_Click);
            // 
            // btnSuaLoaiMon
            // 
            this.btnSuaLoaiMon.Location = new System.Drawing.Point(142, 219);
            this.btnSuaLoaiMon.Name = "btnSuaLoaiMon";
            this.btnSuaLoaiMon.Size = new System.Drawing.Size(91, 44);
            this.btnSuaLoaiMon.TabIndex = 7;
            this.btnSuaLoaiMon.Text = "Sửa";
            this.btnSuaLoaiMon.UseVisualStyleBackColor = true;
            this.btnSuaLoaiMon.Click += new System.EventHandler(this.btnSuaLoaiMon_Click);
            // 
            // txtMaLoaiMon
            // 
            this.txtMaLoaiMon.Location = new System.Drawing.Point(201, 66);
            this.txtMaLoaiMon.Name = "txtMaLoaiMon";
            this.txtMaLoaiMon.ReadOnly = true;
            this.txtMaLoaiMon.Size = new System.Drawing.Size(346, 27);
            this.txtMaLoaiMon.TabIndex = 11;
            // 
            // btnThemLoaiMon
            // 
            this.btnThemLoaiMon.Location = new System.Drawing.Point(30, 219);
            this.btnThemLoaiMon.Name = "btnThemLoaiMon";
            this.btnThemLoaiMon.Size = new System.Drawing.Size(91, 44);
            this.btnThemLoaiMon.TabIndex = 6;
            this.btnThemLoaiMon.Text = "Thêm";
            this.btnThemLoaiMon.UseVisualStyleBackColor = true;
            this.btnThemLoaiMon.Click += new System.EventHandler(this.btnThemLoaiMon_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(55, 145);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 19);
            this.label6.TabIndex = 5;
            this.label6.Text = "Tên loại món";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(55, 64);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(95, 19);
            this.label7.TabIndex = 3;
            this.label7.Text = "Mã loại món";
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.NavajoWhite;
            this.tabPage1.Controls.Add(this.groupBox10);
            this.tabPage1.Controls.Add(this.groupBox7);
            this.tabPage1.Location = new System.Drawing.Point(4, 44);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1267, 661);
            this.tabPage1.TabIndex = 9;
            this.tabPage1.Text = "Tài khoản";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.btnDoiMK_tabTK);
            this.groupBox10.Controls.Add(this.btnXoaTK_tabTK);
            this.groupBox10.Controls.Add(this.btnSuaThongTin_TabTK);
            this.groupBox10.Controls.Add(this.cmbChucVu_tabTaiKhoan);
            this.groupBox10.Controls.Add(this.label10);
            this.groupBox10.Controls.Add(this.label8);
            this.groupBox10.Controls.Add(this.txtTenHienThi_tabTaiKhoan);
            this.groupBox10.Controls.Add(this.btnTaoTK_tabTK);
            this.groupBox10.Controls.Add(this.label12);
            this.groupBox10.Controls.Add(this.txtTaiKhoan_tabTaiKhoan);
            this.groupBox10.Location = new System.Drawing.Point(678, 124);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox10.Size = new System.Drawing.Size(580, 405);
            this.groupBox10.TabIndex = 13;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Thông tin tài khoản";
            // 
            // btnDoiMK_tabTK
            // 
            this.btnDoiMK_tabTK.Location = new System.Drawing.Point(295, 315);
            this.btnDoiMK_tabTK.Margin = new System.Windows.Forms.Padding(2);
            this.btnDoiMK_tabTK.Name = "btnDoiMK_tabTK";
            this.btnDoiMK_tabTK.Size = new System.Drawing.Size(108, 44);
            this.btnDoiMK_tabTK.TabIndex = 21;
            this.btnDoiMK_tabTK.Text = "Đổi mật khẩu";
            this.btnDoiMK_tabTK.UseVisualStyleBackColor = true;
            this.btnDoiMK_tabTK.Click += new System.EventHandler(this.btnDoiMK_tabTK_Click);
            // 
            // btnXoaTK_tabTK
            // 
            this.btnXoaTK_tabTK.Location = new System.Drawing.Point(409, 315);
            this.btnXoaTK_tabTK.Margin = new System.Windows.Forms.Padding(2);
            this.btnXoaTK_tabTK.Name = "btnXoaTK_tabTK";
            this.btnXoaTK_tabTK.Size = new System.Drawing.Size(116, 44);
            this.btnXoaTK_tabTK.TabIndex = 20;
            this.btnXoaTK_tabTK.Text = "Xoá tài khoản";
            this.btnXoaTK_tabTK.UseVisualStyleBackColor = true;
            this.btnXoaTK_tabTK.Click += new System.EventHandler(this.btnXoaTK_tabTK_Click);
            // 
            // btnSuaThongTin_TabTK
            // 
            this.btnSuaThongTin_TabTK.Location = new System.Drawing.Point(180, 315);
            this.btnSuaThongTin_TabTK.Margin = new System.Windows.Forms.Padding(2);
            this.btnSuaThongTin_TabTK.Name = "btnSuaThongTin_TabTK";
            this.btnSuaThongTin_TabTK.Size = new System.Drawing.Size(108, 44);
            this.btnSuaThongTin_TabTK.TabIndex = 19;
            this.btnSuaThongTin_TabTK.Text = "Sửa thông tin";
            this.btnSuaThongTin_TabTK.UseVisualStyleBackColor = true;
            this.btnSuaThongTin_TabTK.Click += new System.EventHandler(this.btnSuaThongTin_TabTK_Click);
            // 
            // cmbChucVu_tabTaiKhoan
            // 
            this.cmbChucVu_tabTaiKhoan.FormattingEnabled = true;
            this.cmbChucVu_tabTaiKhoan.Location = new System.Drawing.Point(179, 203);
            this.cmbChucVu_tabTaiKhoan.Name = "cmbChucVu_tabTaiKhoan";
            this.cmbChucVu_tabTaiKhoan.Size = new System.Drawing.Size(226, 27);
            this.cmbChucVu_tabTaiKhoan.TabIndex = 13;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(60, 206);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(69, 19);
            this.label10.TabIndex = 12;
            this.label10.Text = "Chức vụ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(60, 135);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 19);
            this.label8.TabIndex = 11;
            this.label8.Text = "Tên hiển thị";
            // 
            // txtTenHienThi_tabTaiKhoan
            // 
            this.txtTenHienThi_tabTaiKhoan.Location = new System.Drawing.Point(179, 135);
            this.txtTenHienThi_tabTaiKhoan.Margin = new System.Windows.Forms.Padding(2);
            this.txtTenHienThi_tabTaiKhoan.Name = "txtTenHienThi_tabTaiKhoan";
            this.txtTenHienThi_tabTaiKhoan.Size = new System.Drawing.Size(346, 27);
            this.txtTenHienThi_tabTaiKhoan.TabIndex = 10;
            // 
            // btnTaoTK_tabTK
            // 
            this.btnTaoTK_tabTK.Location = new System.Drawing.Point(64, 315);
            this.btnTaoTK_tabTK.Margin = new System.Windows.Forms.Padding(2);
            this.btnTaoTK_tabTK.Name = "btnTaoTK_tabTK";
            this.btnTaoTK_tabTK.Size = new System.Drawing.Size(108, 44);
            this.btnTaoTK_tabTK.TabIndex = 9;
            this.btnTaoTK_tabTK.Text = "Tạo tài khoản";
            this.btnTaoTK_tabTK.UseVisualStyleBackColor = true;
            this.btnTaoTK_tabTK.Click += new System.EventHandler(this.btnTaoTK_tabTK_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(60, 67);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(81, 19);
            this.label12.TabIndex = 1;
            this.label12.Text = "Tài khoản";
            // 
            // txtTaiKhoan_tabTaiKhoan
            // 
            this.txtTaiKhoan_tabTaiKhoan.Location = new System.Drawing.Point(179, 64);
            this.txtTaiKhoan_tabTaiKhoan.Margin = new System.Windows.Forms.Padding(2);
            this.txtTaiKhoan_tabTaiKhoan.Name = "txtTaiKhoan_tabTaiKhoan";
            this.txtTaiKhoan_tabTaiKhoan.ReadOnly = true;
            this.txtTaiKhoan_tabTaiKhoan.Size = new System.Drawing.Size(346, 27);
            this.txtTaiKhoan_tabTaiKhoan.TabIndex = 0;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.dgvTK);
            this.groupBox7.Location = new System.Drawing.Point(24, 24);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(621, 602);
            this.groupBox7.TabIndex = 1;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Quản lý tài khoản";
            // 
            // dgvTK
            // 
            this.dgvTK.AllowUserToAddRows = false;
            this.dgvTK.AllowUserToDeleteRows = false;
            this.dgvTK.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTK.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column5,
            this.Column6,
            this.Column7});
            this.dgvTK.Location = new System.Drawing.Point(17, 26);
            this.dgvTK.Name = "dgvTK";
            this.dgvTK.ReadOnly = true;
            this.dgvTK.RowHeadersVisible = false;
            this.dgvTK.Size = new System.Drawing.Size(583, 552);
            this.dgvTK.TabIndex = 0;
            this.dgvTK.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTK_CellClick);
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "TAIKHOAN";
            this.Column5.HeaderText = "Tài khoản";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 180;
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "TENHIENTHI";
            this.Column6.HeaderText = "Tên hiển thị";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Width = 200;
            // 
            // Column7
            // 
            this.Column7.DataPropertyName = "TENCHUCVU";
            this.Column7.HeaderText = "Chức vụ";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Width = 200;
            // 
            // printDoc_Hoadon
            // 
            this.printDoc_Hoadon.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDoc_Hoadon_PrintPage);
            // 
            // printPreview_Hoadon
            // 
            this.printPreview_Hoadon.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreview_Hoadon.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreview_Hoadon.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreview_Hoadon.Enabled = true;
            this.printPreview_Hoadon.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreview_Hoadon.Icon")));
            this.printPreview_Hoadon.Name = "printPreview_Hoadon";
            this.printPreview_Hoadon.Visible = false;
            // 
            // Coffee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1269, 703);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Coffee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Order";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Coffee_FormClosing);
            this.Load += new System.EventHandler(this.Coffee_Load);
            this.SizeChanged += new System.EventHandler(this.Coffee_SizeChanged);
            ((System.ComponentModel.ISupportInitialize)(this.error)).EndInit();
            this.Order.ResumeLayout(false);
            this.Order.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.grbox_Ban.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.slOrder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrder)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.Menu.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtvgMenu)).EndInit();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.LoaiMon.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvLoaiMon)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTK)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ErrorProvider error;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Order;
        private System.Windows.Forms.GroupBox grbox_Ban;
        private System.Windows.Forms.Button btn16;
        private System.Windows.Forms.Button btn15;
        private System.Windows.Forms.Button btn14;
        private System.Windows.Forms.Button btn13;
        private System.Windows.Forms.Button btn12;
        private System.Windows.Forms.Button btn11;
        private System.Windows.Forms.Button btn10;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cboxDouong;
        private System.Windows.Forms.Button btnThemMon;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown slOrder;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cboxDanhmucOrder;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.ComboBox cbox_Chuyenban;
        private System.Windows.Forms.Button btnChuyenban;
        private System.Windows.Forms.Button btnDangXuat;
        private System.Windows.Forms.Button QRCode;
        private System.Windows.Forms.DataGridView dgvOrder;
        private System.Windows.Forms.Button btnThanhToan;
        private System.Windows.Forms.TextBox txtThanhToan;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabPage Menu;
        private System.Windows.Forms.DataGridView dtvgMenu;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.ComboBox cb_LoaiMon;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txt_TenMon;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txt_MaMon;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox txt_DonGia;
        private System.Windows.Forms.Button btn_TimKiemMenu;
        private System.Windows.Forms.Button btn_XoaMenu;
        private System.Windows.Forms.Button btn_SuaMenu;
        private System.Windows.Forms.Button btn_ThemMenu;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cboxDanhmucTenban;
        private System.Drawing.Printing.PrintDocument printDoc_Hoadon;
        private System.Windows.Forms.PrintPreviewDialog printPreview_Hoadon;
        private System.Windows.Forms.TabPage LoaiMon;
        private System.Windows.Forms.DataGridView dgvLoaiMon;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnXoaLoaiMon;
        private System.Windows.Forms.Button btnSuaLoaiMon;
        private System.Windows.Forms.TextBox txtMaLoaiMon;
        private System.Windows.Forms.Button btnThemLoaiMon;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnTimKiemLoaiMon;
        private System.Windows.Forms.TextBox txtTenLoaiMon;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnReloadLoaiMon;
        private System.Windows.Forms.DataGridViewTextBoxColumn MAMON;
        private System.Windows.Forms.DataGridViewTextBoxColumn TENMON;
        private System.Windows.Forms.DataGridViewTextBoxColumn SOLUONG;
        private System.Windows.Forms.DataGridViewTextBoxColumn THANHTIEN;
        private System.Windows.Forms.DataGridViewTextBoxColumn MALOAI;
        private System.Windows.Forms.DataGridViewTextBoxColumn TENLOAI;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btn_ReLoad;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dgvTK;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.ComboBox cmbChucVu_tabTaiKhoan;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtTenHienThi_tabTaiKhoan;
        private System.Windows.Forms.Button btnTaoTK_tabTK;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtTaiKhoan_tabTaiKhoan;
        private System.Windows.Forms.Button btnSuaThongTin_TabTK;
        private System.Windows.Forms.Button btnDoiMK_tabTK;
        private System.Windows.Forms.Button btnXoaTK_tabTK;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaMonMenu;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenMonMenu;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenLoaiMonMenu;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaMenu;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox ckbTK_DonGia;
        private System.Windows.Forms.CheckBox ckbTK_LoaiMon;
        private System.Windows.Forms.CheckBox ckbTK_TenMon;
    }
}

